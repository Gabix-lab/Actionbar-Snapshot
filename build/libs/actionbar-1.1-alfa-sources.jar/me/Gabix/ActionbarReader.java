package me.Gabix;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_337;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ActionbarReader {
    private static class_304 readKeyBinding;
    private static class_304 readBossBarsKeyBinding;
    private static String lastRawActionbarText = "";
    private static final Pattern MANA_PATTERN = Pattern.compile("§b(\\d+)§8/§b\\d+");
    private static final Pattern DAMAGE_PATTERN = Pattern.compile("Sebzés:⿀§f(\\d+)");

    public static void init() {
        readKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.actionbarstorage.read",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                "category.actionbarstorage"
        ));
        readBossBarsKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.actionbarstorage.read_bossbars",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                "category.actionbarstorage"
        ));
    }

    public static void handleTick(class_310 client) {
        if (client.field_1724 == null) return;

        // --- AUTOMATIKUS ELLENŐRZÉS MINDEN TICKBEN ---
        try {
            if (client.field_1705 != null) {
                class_337 bossBarHud = client.field_1705.method_1740();
                Field bossBarsField = null;
                for (Field field : class_337.class.getDeclaredFields()) {
                    if (Map.class.isAssignableFrom(field.getType())) {
                        field.setAccessible(true);
                        bossBarsField = field;
                        break;
                    }
                }

                if (bossBarsField != null) {
                    Map<?, ?> bossBars = (Map<?, ?>) bossBarsField.get(bossBarHud);
                    if (bossBars != null && !bossBars.isEmpty()) {
                        for (Object value : bossBars.values()) {
                            if (value instanceof class_1259 bossBar) {
                                String cleanBossName = bossBar.method_5414().getString().toLowerCase();
                                StorageConfig config = ActionbarStorageClient.getConfig();

                                if (config != null) {
                                    String targetBoss = null;

                                    // Endermágus
                                    if (cleanBossName.contains("ender") && cleanBossName.contains("mágus")) {
                                        targetBoss = "Endermágus";
                                    }
                                    // Trex
                                    else if (cleanBossName.contains("trex")) {
                                        targetBoss = "Trex";
                                    }
                                    // Warden
                                    else if (cleanBossName.contains("warden")) {
                                        targetBoss = "Warden";
                                    }
                                    // Radio Pók
                                    else if (cleanBossName.contains("radio") && (cleanBossName.contains("pók") || cleanBossName.contains("pok"))) {
                                        targetBoss = "RadioPók";
                                    }
                                    // JégSárkány / Ice Dragon
                                    else if (((cleanBossName.contains("jég") || cleanBossName.contains("jeg")) && (cleanBossName.contains("sárkány") || cleanBossName.contains("sarkany"))) || cleanBossName.contains("ice dragon")) {
                                        targetBoss = "JégSárkány";
                                    }
                                    // Kraken
                                    else if (cleanBossName.contains("kraken")) {
                                        targetBoss = "Kraken";
                                    }

                                    // Ha találtunk megfelelő bosst ÉS még nem az van beállítva, akkor átváltunk és kiírjuk a képernyőre
                                    if (targetBoss != null && !config.selectedBossNotification.equals(targetBoss)) {
                                        config.selectedBossNotification = targetBoss;

                                        // Megjelenítés a képernyő közepén (Beúszás: 5 tick, Látható: 40 tick (~2 mp), Eltűnés: 5 tick)
                                        client.field_1705.method_34001(5, 40, 5);
                                        client.field_1705.method_34004(class_2561.method_43470("§d§lMÓD VÁLTVA"));
                                        client.field_1705.method_34002(class_2561.method_43470("§eProfil automatikusan átállítva: §b" + targetBoss));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        // ---------------------------------------------

        while (readKeyBinding.method_1436()) {
            if (lastRawActionbarText == null || lastRawActionbarText.isEmpty()) {
                client.field_1724.method_7353(class_2561.method_43470("§c[Actionbar] Nincs elmentett actionbar szöveg!"), false);
            } else {
                client.field_1724.method_7353(class_2561.method_43470("§a[Actionbar Nyers]: §r" + lastRawActionbarText), false);
            }
        }

        while (readBossBarsKeyBinding.method_1436()) {
            try {
                class_337 bossBarHud = client.field_1705.method_1740();
                Field bossBarsField = null;
                for (Field field : class_337.class.getDeclaredFields()) {
                    if (Map.class.isAssignableFrom(field.getType())) {
                        field.setAccessible(true);
                        bossBarsField = field;
                        break;
                    }
                }

                if (bossBarsField != null) {
                    Map<?, ?> bossBars = (Map<?, ?>) bossBarsField.get(bossBarHud);
                    if (bossBars == null || bossBars.isEmpty()) {
                        client.field_1724.method_7353(class_2561.method_43470("§c[Bossbar] Nincs látható bossbar!"), false);
                    } else {
                        client.field_1724.method_7353(class_2561.method_43470("§6--- Aktív Bossbarok Nyersen ---"), false);
                        for (Object value : bossBars.values()) {
                            if (value instanceof class_1259 bossBar) {
                                String rawText = toRawLegacyText(bossBar.method_5414());
                                client.field_1724.method_7353(class_2561.method_43470("§e[Bossbar Nyers]: §r" + rawText), false);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                client.field_1724.method_7353(class_2561.method_43470("§c[Bossbar] Hiba történt: " + e.getMessage()), false);
            }
        }
    }

    public static void updateText(class_2561 text) {
        if (text == null) return;

        lastRawActionbarText = toRawLegacyText(text);

        if (ActionbarStorageClient.getInstance() != null && ActionbarStorageClient.getInstance().getManaManager() != null) {
            ManaManager manaManager = ActionbarStorageClient.getInstance().getManaManager();
            StorageConfig config = ActionbarStorageClient.getInstance().getConfig();
            String cleanText = text.getString();

            Matcher manaMatcher = MANA_PATTERN.matcher(cleanText);
            if (manaMatcher.find()) {
                try {
                    int foundMana = Integer.parseInt(manaMatcher.group(1));
                    manaManager.setCurrentMana(foundMana);
                } catch (NumberFormatException ignored) {}
            }

            Matcher dmgMatcher = DAMAGE_PATTERN.matcher(cleanText);
            if (dmgMatcher.find()) {
                try {
                    int foundDamage = Integer.parseInt(dmgMatcher.group(1));
                    manaManager.setCurrentDamage(foundDamage);

                    if (config != null && !config.selectedBossNotification.equals("Ki")) {
                        if (foundDamage >= config.getTargetBossDamage()) {
                            if (class_310.method_1551().field_1705 != null) {
                                class_310.method_1551().field_1705.method_34001(0, 20, 0);
                                class_310.method_1551().field_1705.method_34004(class_2561.method_43470("§a§l★ KÉSZ ★"));
                                class_310.method_1551().field_1705.method_34002(class_2561.method_43470("§eSebzés elérve: §6" + foundDamage));
                            }
                        }
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    private static String toRawLegacyText(class_2561 text) {
        if (text == null) return "";
        StringBuilder raw = new StringBuilder();
        text.method_27658((style, string) -> {
            if (style != null) {
                if (style.method_10973() != null) {
                    String colorName = style.method_10973().method_27721();
                    switch (colorName) {
                        case "black" -> raw.append("&0");
                        case "dark_blue" -> raw.append("&1");
                        case "dark_green" -> raw.append("&2");
                        case "dark_aqua" -> raw.append("&3");
                        case "dark_red" -> raw.append("&4");
                        case "dark_purple" -> raw.append("&5");
                        case "gold" -> raw.append("&6");
                        case "gray" -> raw.append("&7");
                        case "dark_gray" -> raw.append("&8");
                        case "blue" -> raw.append("&9");
                        case "green" -> raw.append("&a");
                        case "aqua" -> raw.append("&b");
                        case "red" -> raw.append("&c");
                        case "light_purple" -> raw.append("&d");
                        case "yellow" -> raw.append("&e");
                        case "white" -> raw.append("&f");
                    }
                }
                if (style.method_10987()) raw.append("&k");
                if (style.method_10984()) raw.append("&l");
                if (style.method_10986()) raw.append("&m");
                if (style.method_10965()) raw.append("&n");
                if (style.method_10966()) raw.append("&o");
            }
            raw.append(string);
            return Optional.empty();
        }, net.minecraft.class_2583.field_24360);
        return raw.toString();
    }

    public static String getLastRawActionbarText() {
        return lastRawActionbarText;
    }
}