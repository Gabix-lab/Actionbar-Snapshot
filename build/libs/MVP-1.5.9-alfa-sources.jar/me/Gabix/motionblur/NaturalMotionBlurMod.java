package me.Gabix.motionblur;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.joml.Matrix4f;

import ladysnake.satin.api.event.PostWorldRenderCallback;
import ladysnake.satin.api.managed.ManagedShaderEffect;
import ladysnake.satin.api.managed.ShaderEffectManager;

public class NaturalMotionBlurMod implements ClientModInitializer {
    private static ManagedShaderEffect motionBlurEffect;
    private static boolean enabled = true;
    private static class_304 toggleKey;

    private static class_243 prevCameraPos = class_243.field_1353;
    private static Matrix4f prevModelView = new Matrix4f();
    private static Matrix4f prevProjection = new Matrix4f();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "MotionBlur ki/be kapcsolás",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                "MotionBlur"
        ));

        motionBlurEffect = ShaderEffectManager.getInstance()
                .manage(new class_2960("mvp", "shaders/post/motion_blur.json"));

        PostWorldRenderCallback.EVENT.register((camera, tickDelta, nanoTime) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1687 == null) return;

            if (enabled && motionBlurEffect != null) {
                class_243 currentCameraPos = camera.method_19326();

                // Uniform alapértékek
                motionBlurEffect.setUniformValue("BlendFactor", 0.7f);
                motionBlurEffect.setUniformValue("motionBlurSamples", 7);
                motionBlurEffect.setUniformValue("useDepth", 1);
                motionBlurEffect.setUniformValue("blurAlgorithm", 0);

                // Kamera pozíciók
                motionBlurEffect.setUniformValue("cameraPos",
                        (float) currentCameraPos.field_1352, (float) currentCameraPos.field_1351, (float) currentCameraPos.field_1350);
                motionBlurEffect.setUniformValue("prevCameraPos",
                        (float) prevCameraPos.field_1352, (float) prevCameraPos.field_1351, (float) prevCameraPos.field_1350);

                // Mátrixok kiszámítása és átadása
                Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix());
                Matrix4f projection = new Matrix4f(RenderSystem.getProjectionMatrix());

                Matrix4f mvInverse = new Matrix4f(modelView).invert();
                Matrix4f projInverse = new Matrix4f(projection).invert();

                motionBlurEffect.setUniformValue("mvInverse", mvInverse);
                motionBlurEffect.setUniformValue("projInverse", projInverse);
                motionBlurEffect.setUniformValue("prevModelView", prevModelView);
                motionBlurEffect.setUniformValue("prevProjection", prevProjection);

                motionBlurEffect.render(tickDelta);

                prevCameraPos = currentCameraPos;
                prevModelView = modelView;
                prevProjection = projection;
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                enabled = !enabled;

                if (client.field_1724 != null) {
                    class_2561 statusText = enabled
                            ? class_2561.method_43470("be").method_27692(class_124.field_1060)
                            : class_2561.method_43470("ki").method_27692(class_124.field_1061);

                    class_2561 message = class_2561.method_43470("§f[GabixMod] §7MotionBlur: ").method_10852(statusText);

                    client.field_1724.method_7353(message, true);
                }
            }
        });
    }
}