package me.Gabix.badge;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_642;

public class ModServerClient {
    private static final String BASE_URL = "https://mvp-backend-bods.onrender.com/api";
    private static final Gson GSON = new Gson();

    private static String getPlayerName(class_310 client) {
        if (client.field_1724 != null) {
            return client.field_1724.method_5477().getString();
        } else {
            return client.method_1548() != null ? client.method_1548().method_1676() : "Unknown";
        }
    }

    private static String getCurrentServerIp(class_310 client) {
        if (client.method_1496()) {
            if (client.method_1576() != null && client.method_1576().method_27728() != null) {
                String levelName = client.method_1576().method_27728().method_150();
                return "Singleplayer (" + levelName + ")";
            } else {
                return "Singleplayer";
            }
        } else {
            class_642 serverEntry = client.method_1558();
            if (serverEntry != null && serverEntry.field_3761 != null && !serverEntry.field_3761.isEmpty()) {
                return serverEntry.field_3761;
            } else {
                class_634 networkHandler = client.method_1562();
                if (networkHandler != null && networkHandler.method_48296() != null) {
                    String address = networkHandler.method_48296().method_10755().toString();
                    if (address.contains("/")) {
                        String host = address.split("/")[0];
                        return !host.isEmpty() ? host : address.split("/")[1];
                    } else {
                        return address;
                    }
                } else {
                    return "In game main menu";
                }
            }
        }
    }

    public static void sendHeartbeatAsync(UUID uuid) {
        if (uuid != null) {
            class_310 client = class_310.method_1551();
            String username = getPlayerName(client);
            String serverIp = getCurrentServerIp(client);
            CompletableFuture.runAsync(() -> {
                try {
                    URL url = new URL(BASE_URL + "/heartbeat");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);
                    conn.setDoOutput(true);

                    JsonObject jsonBody = new JsonObject();
                    jsonBody.addProperty("uuid", uuid.toString());
                    jsonBody.addProperty("username", username);
                    jsonBody.addProperty("serverIp", serverIp);

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(jsonBody.toString().getBytes(StandardCharsets.UTF_8));
                    }

                    conn.getResponseCode();
                    conn.disconnect();
                } catch (Exception ignored) {}
            });
        }
    }

    public static void sendLogoutAsync(UUID uuid) {
        if (uuid != null) {
            CompletableFuture.runAsync(() -> {
                try {
                    URL url = new URL(BASE_URL + "/logout");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setConnectTimeout(3000);
                    conn.setReadTimeout(3000);
                    conn.setDoOutput(true);

                    JsonObject jsonBody = new JsonObject();
                    jsonBody.addProperty("uuid", uuid.toString());

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(jsonBody.toString().getBytes(StandardCharsets.UTF_8));
                    }

                    conn.getResponseCode();
                    conn.disconnect();
                } catch (Exception ignored) {}
            });
        }
    }

    public static void fetchUsersAsync() {
        CompletableFuture.runAsync(() -> {
            try {
                URL url = new URL(BASE_URL + "/users");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                if (conn.getResponseCode() == 200) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder content = new StringBuilder();
                    String inputLine;

                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }
                    in.close();

                    JsonObject obj = GSON.fromJson(content.toString(), JsonObject.class);
                    if (obj.has("users")) {
                        JsonArray arr = obj.getAsJsonArray("users");
                        Set<UUID> fetchedUuids = new HashSet<>();

                        for (JsonElement el : arr) {
                            fetchedUuids.add(UUID.fromString(el.getAsString()));
                        }

                        ModPlayerTracker.updateUsers(fetchedUuids);
                    }
                }
                conn.disconnect();
            } catch (Exception ignored) {}
        });
    }
}