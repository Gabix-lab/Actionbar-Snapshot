package me.Gabix.badge.mixin;

import me.Gabix.badge.ModPlayerTracker;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public class PlayerEntityMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void addIconToDisplayName(CallbackInfoReturnable<class_2561> cir) {
        class_1657 player = (class_1657) (Object) this;

        if (ModPlayerTracker.usesMod(player.method_5667(), player.method_7334().getName())) {
            class_2561 originalName = cir.getReturnValue();
            if (originalName != null && !originalName.getString().contains("\ue001")) {
                class_5250 nameWithIcon = class_2561.method_43470("\ue001 ").method_10852(originalName);
                cir.setReturnValue(nameWithIcon);
            }
        }
    }
}