package me.Gabix.badge.mixin;

import me.Gabix.badge.ModPlayerTracker;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.authlib.GameProfile;

@Mixin(class_640.class)
public abstract class PlayerListEntryMixin {

    @Shadow public abstract GameProfile getProfile();
    @Shadow private class_2561 displayName;

    private static final class_2960 DEFAULT_FONT = class_2960.method_43902("minecraft", "default");
    private static final ThreadLocal<Boolean> IS_PROCESSING = ThreadLocal.withInitial(() -> false);

    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void overridePlayerName(CallbackInfoReturnable<class_2561> cir) {
        if (IS_PROCESSING.get()) {
            return;
        }

        try {
            IS_PROCESSING.set(true);

            class_640 entry = (class_640) (Object) this;
            class_310 client = class_310.method_1551();

            if (client.field_1724 != null && entry.method_2966() != null) {
                boolean isSelf = entry.method_2966().getId().equals(client.field_1724.method_5667());
                boolean isModUser = ModPlayerTracker.usesMod(entry.method_2966().getId());

                if (isSelf || isModUser) {
                    class_2561 baseDisplayName = this.displayName;
                    if (baseDisplayName == null) {
                        baseDisplayName = class_2561.method_43470(entry.method_2966().getName());
                    }

                    if (!baseDisplayName.getString().contains("\ue001")) {
                        class_2583 iconStyle = class_2583.field_24360.method_27704(DEFAULT_FONT).method_36139(0xFFFFFF);
                        class_5250 iconPrefix = class_2561.method_43470("\ue001 ").method_10862(iconStyle);

                        class_5250 finalTabName = class_2561.method_43473();
                        finalTabName.method_10852(iconPrefix);
                        finalTabName.method_10852(baseDisplayName);

                        cir.setReturnValue(finalTabName);
                    }
                }
            }
        } finally {
            IS_PROCESSING.set(false);
        }
    }
}