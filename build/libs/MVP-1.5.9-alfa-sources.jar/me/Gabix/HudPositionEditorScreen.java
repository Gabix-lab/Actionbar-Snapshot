package me.Gabix;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class HudPositionEditorScreen extends class_437 {
    private final StorageConfig config;
    private final class_437 parent;

    private DragTarget draggingTarget = null;
    private int draggedSlotIndex = -1;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    private static final int SNAP_THRESHOLD = 5;

    private enum DragTarget {
        MANA, DAMAGE, SLOT, FPS, CPS
    }

    private static class BoxBounds {
        int x, y, w, h;
        DragTarget target;
        int slotIndex;

        BoxBounds(int x, int y, int w, int h, DragTarget target, int slotIndex) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.target = target;
            this.slotIndex = slotIndex;
        }
    }

    public HudPositionEditorScreen(StorageConfig config, class_437 parent) {
        super(class_2561.method_43470("HUD Szerkesztő"));
        this.config = config;
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Kész & Mentés"), button -> {
            this.config.save();
            if (this.field_22787 != null) {
                this.field_22787.method_1507(this.parent);
            }
        }).method_46434(this.field_22789 / 2 - 75, this.field_22790 - 28, 150, 20).method_46431());
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int manaW = (int) (80 * config.manaScale);
            int manaH = (int) (16 * config.manaScale);
            if (isHovered(config.manaX, config.manaY, manaW, manaH, mouseX, mouseY)) {
                draggingTarget = DragTarget.MANA;
                dragOffsetX = (int) mouseX - config.manaX;
                dragOffsetY = (int) mouseY - config.manaY;
                return true;
            }

            int dmgW = (int) (80 * config.damageScale);
            int dmgH = (int) (16 * config.damageScale);
            if (isHovered(config.damageX, config.damageY, dmgW, dmgH, mouseX, mouseY)) {
                draggingTarget = DragTarget.DAMAGE;
                dragOffsetX = (int) mouseX - config.damageX;
                dragOffsetY = (int) mouseY - config.damageY;
                return true;
            }

            int fpsW = (int) (60 * config.fpsScale);
            int fpsH = (int) (16 * config.fpsScale);
            if (isHovered(config.fpsX, config.fpsY, fpsW, fpsH, mouseX, mouseY)) {
                draggingTarget = DragTarget.FPS;
                dragOffsetX = (int) mouseX - config.fpsX;
                dragOffsetY = (int) mouseY - config.fpsY;
                return true;
            }

            int cpsW = (int) (80 * config.cpsScale);
            int cpsH = (int) (16 * config.cpsScale);
            if (isHovered(config.cpsX, config.cpsY, cpsW, cpsH, mouseX, mouseY)) {
                draggingTarget = DragTarget.CPS;
                dragOffsetX = (int) mouseX - config.cpsX;
                dragOffsetY = (int) mouseY - config.cpsY;
                return true;
            }

            for (int i = 0; i < 9; i++) {
                int slotW = (int) (18 * config.hudSlotsScale[i]);
                int slotH = (int) (18 * config.hudSlotsScale[i]);
                if (isHovered(config.hudSlotsX[i], config.hudSlotsY[i], slotW, slotH, mouseX, mouseY)) {
                    draggingTarget = DragTarget.SLOT;
                    draggedSlotIndex = i;
                    dragOffsetX = (int) mouseX - config.hudSlotsX[i];
                    dragOffsetY = (int) mouseY - config.hudSlotsY[i];
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingTarget != null) {
            int rawX = (int) mouseX - dragOffsetX;
            int rawY = (int) mouseY - dragOffsetY;

            int targetW = getTargetWidth(draggingTarget, draggedSlotIndex);
            int targetH = getTargetHeight(draggingTarget, draggedSlotIndex);

            int snappedX = applySnapX(rawX, targetW, draggingTarget, draggedSlotIndex);
            int snappedY = applySnapY(rawY, targetH, draggingTarget, draggedSlotIndex);

            snappedX = Math.max(0, Math.min(this.field_22789 - targetW, snappedX));
            snappedY = Math.max(0, Math.min(this.field_22790 - targetH, snappedY));

            switch (draggingTarget) {
                case MANA -> { config.manaX = snappedX; config.manaY = snappedY; }
                case DAMAGE -> { config.damageX = snappedX; config.damageY = snappedY; }
                case FPS -> { config.fpsX = snappedX; config.fpsY = snappedY; }
                case CPS -> { config.cpsX = snappedX; config.cpsY = snappedY; }
                case SLOT -> {
                    if (draggedSlotIndex >= 0 && draggedSlotIndex < 9) {
                        config.hudSlotsX[draggedSlotIndex] = snappedX;
                        config.hudSlotsY[draggedSlotIndex] = snappedY;
                    }
                }
            }
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        float delta = amount > 0 ? 0.1f : -0.1f;

        int manaW = (int) (80 * config.manaScale);
        int manaH = (int) (16 * config.manaScale);
        if (isHovered(config.manaX, config.manaY, manaW, manaH, mouseX, mouseY)) {
            config.manaScale = Math.max(0.5f, Math.min(3.0f, config.manaScale + delta));
            return true;
        }

        int dmgW = (int) (80 * config.damageScale);
        int dmgH = (int) (16 * config.damageScale);
        if (isHovered(config.damageX, config.damageY, dmgW, dmgH, mouseX, mouseY)) {
            config.damageScale = Math.max(0.5f, Math.min(3.0f, config.damageScale + delta));
            return true;
        }

        int fpsW = (int) (60 * config.fpsScale);
        int fpsH = (int) (16 * config.fpsScale);
        if (isHovered(config.fpsX, config.fpsY, fpsW, fpsH, mouseX, mouseY)) {
            config.fpsScale = Math.max(0.5f, Math.min(3.0f, config.fpsScale + delta));
            return true;
        }

        int cpsW = (int) (80 * config.cpsScale);
        int cpsH = (int) (16 * config.cpsScale);
        if (isHovered(config.cpsX, config.cpsY, cpsW, cpsH, mouseX, mouseY)) {
            config.cpsScale = Math.max(0.5f, Math.min(3.0f, config.cpsScale + delta));
            return true;
        }

        for (int i = 0; i < 9; i++) {
            int slotW = (int) (18 * config.hudSlotsScale[i]);
            int slotH = (int) (18 * config.hudSlotsScale[i]);
            if (isHovered(config.hudSlotsX[i], config.hudSlotsY[i], slotW, slotH, mouseX, mouseY)) {
                config.hudSlotsScale[i] = Math.max(0.5f, Math.min(3.0f, config.hudSlotsScale[i] + delta));
                return true;
            }
        }

        return super.method_25401(mouseX, mouseY, amount);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        draggingTarget = null;
        draggedSlotIndex = -1;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);

        method_25300(matrices, this.field_22793, "Húzás = Mozgatás | Görgő = Méretezés | Mágneses igazítás bekapcsolva", this.field_22789 / 2, 8, 0xFFFF55);

        int manaW = (int) (80 * config.manaScale);
        int manaH = (int) (16 * config.manaScale);
        renderBox(matrices, config.manaX, config.manaY, manaW, manaH, "§bMana", config.showMana, mouseX, mouseY);

        int dmgW = (int) (80 * config.damageScale);
        int dmgH = (int) (16 * config.damageScale);
        renderBox(matrices, config.damageX, config.damageY, dmgW, dmgH, "§cSebzés", config.showDamage, mouseX, mouseY);

        int fpsW = (int) (60 * config.fpsScale);
        int fpsH = (int) (16 * config.fpsScale);
        renderBox(matrices, config.fpsX, config.fpsY, fpsW, fpsH, "§aFPS", config.showFps, mouseX, mouseY);

        int cpsW = (int) (80 * config.cpsScale);
        int cpsH = (int) (16 * config.cpsScale);
        renderBox(matrices, config.cpsX, config.cpsY, cpsW, cpsH, "§bCPS", config.showCps, mouseX, mouseY);

        for (int i = 0; i < 9; i++) {
            boolean enabled = config.hudSlotsEnabled[i];
            int slotSize = (int) (18 * config.hudSlotsScale[i]);
            int sx = config.hudSlotsX[i];
            int sy = config.hudSlotsY[i];
            boolean hovered = isHovered(sx, sy, slotSize, slotSize, mouseX, mouseY);

            int bgColor = hovered ? 0xAA00FF00 : (enabled ? 0x8822AA22 : 0x88AA2222);
            method_25294(matrices, sx, sy, sx + slotSize, sy + slotSize, bgColor);
            drawCustomBorder(matrices, sx, sy, slotSize, slotSize, hovered ? 0xFF00FF00 : 0xFFFFFFFF);

            String label = String.valueOf(i + 1);
            this.field_22793.method_1720(matrices, label, sx + slotSize / 2 - 3, sy + slotSize / 2 - 4, 0xFFFFFF);
        }

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    private int applySnapX(int x, int width, DragTarget currentTarget, int currentSlotIndex) {
        for (BoxBounds b : getAllOtherBoxes(currentTarget, currentSlotIndex)) {
            if (Math.abs(x - b.x) < SNAP_THRESHOLD) return b.x;
            if (Math.abs((x + width) - b.x) < SNAP_THRESHOLD) return b.x - width;
            if (Math.abs(x - (b.x + b.w)) < SNAP_THRESHOLD) return b.x + b.w;
            if (Math.abs((x + width) - (b.x + b.w)) < SNAP_THRESHOLD) return b.x + b.w - width;
        }
        return x;
    }

    private int applySnapY(int y, int height, DragTarget currentTarget, int currentSlotIndex) {
        for (BoxBounds b : getAllOtherBoxes(currentTarget, currentSlotIndex)) {
            if (Math.abs(y - b.y) < SNAP_THRESHOLD) return b.y;
            if (Math.abs((y + height) - b.y) < SNAP_THRESHOLD) return b.y - height;
            if (Math.abs(y - (b.y + b.h)) < SNAP_THRESHOLD) return b.y + b.h;
            if (Math.abs((y + height) - (b.y + b.h)) < SNAP_THRESHOLD) return b.y + b.h - height;
        }
        return y;
    }

    private List<BoxBounds> getAllOtherBoxes(DragTarget ignoreTarget, int ignoreSlotIndex) {
        List<BoxBounds> list = new ArrayList<>();
        if (ignoreTarget != DragTarget.MANA)
            list.add(new BoxBounds(config.manaX, config.manaY, (int)(80 * config.manaScale), (int)(16 * config.manaScale), DragTarget.MANA, -1));
        if (ignoreTarget != DragTarget.DAMAGE)
            list.add(new BoxBounds(config.damageX, config.damageY, (int)(80 * config.damageScale), (int)(16 * config.damageScale), DragTarget.DAMAGE, -1));
        if (ignoreTarget != DragTarget.FPS)
            list.add(new BoxBounds(config.fpsX, config.fpsY, (int)(60 * config.fpsScale), (int)(16 * config.fpsScale), DragTarget.FPS, -1));
        if (ignoreTarget != DragTarget.CPS)
            list.add(new BoxBounds(config.cpsX, config.cpsY, (int)(80 * config.cpsScale), (int)(16 * config.cpsScale), DragTarget.CPS, -1));

        for (int i = 0; i < 9; i++) {
            if (ignoreTarget == DragTarget.SLOT && ignoreSlotIndex == i) continue;
            int slotSize = (int)(18 * config.hudSlotsScale[i]);
            list.add(new BoxBounds(config.hudSlotsX[i], config.hudSlotsY[i], slotSize, slotSize, DragTarget.SLOT, i));
        }
        return list;
    }

    private int getTargetWidth(DragTarget target, int slotIndex) {
        return switch (target) {
            case MANA -> (int) (80 * config.manaScale);
            case DAMAGE -> (int) (80 * config.damageScale);
            case FPS -> (int) (60 * config.fpsScale);
            case CPS -> (int) (80 * config.cpsScale);
            case SLOT -> (int) (18 * config.hudSlotsScale[slotIndex]);
        };
    }

    private int getTargetHeight(DragTarget target, int slotIndex) {
        return switch (target) {
            case MANA -> (int) (16 * config.manaScale);
            case DAMAGE -> (int) (16 * config.damageScale);
            case FPS -> (int) (16 * config.fpsScale);
            case CPS -> (int) (16 * config.cpsScale);
            case SLOT -> (int) (18 * config.hudSlotsScale[slotIndex]);
        };
    }

    private void renderBox(class_4587 matrices, int x, int y, int w, int h, String text, boolean isEnabledInConfig, int mouseX, int mouseY) {
        boolean hovered = isHovered(x, y, w, h, mouseX, mouseY);
        int bgColor = hovered ? 0xAA00FF00 : (isEnabledInConfig ? 0x77000000 : 0x77AA0000);
        method_25294(matrices, x, y, x + w, y + h, bgColor);
        drawCustomBorder(matrices, x, y, w, h, hovered ? 0xFF00FF00 : (isEnabledInConfig ? 0xFFFFFFFF : 0xFFFF5555));
        String fullText = text + (isEnabledInConfig ? "" : " §c(KI)");
        this.field_22793.method_1720(matrices, fullText, x + 4, y + h / 2 - 4, 0xFFFFFF);
    }

    private void drawCustomBorder(class_4587 matrices, int x, int y, int w, int h, int color) {
        method_25294(matrices, x, y, x + w, y + 1, color);
        method_25294(matrices, x, y + h - 1, x + w, y + h, color);
        method_25294(matrices, x, y, x + 1, y + h, color);
        method_25294(matrices, x + w - 1, y, x + w, y + h, color);
    }

    private boolean isHovered(int x, int y, int w, int h, double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }
}