package me.Gabix;

import me.Gabix.badge.ModPlayerTracker;
import me.Gabix.badge.ModServerClient;
import me.Gabix.developer.DeveloperModClient;
import me.Gabix.fpsreducer.FpsManager;
import me.Gabix.fullbirghtnesstoggle.FullbrightModClient;
import me.Gabix.motionblur.NaturalMotionBlurMod;
import me.Gabix.norender.NoRenderEngine;
import me.Gabix.soundreducer.MuteOnInactive;
import me.Gabix.soundreducer.SoundReducer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public class ActionbarStorageClient implements ClientModInitializer {
    private static ActionbarStorageClient instance;
    private static StorageConfig savedConfig;
    private final ScheduledExecutorService scheduler = new ScheduledThreadPoolExecutor(2);
    private final ManaManager manaManager = new ManaManager();
    private final CloneManager cloneManager = new CloneManager();
    private final FpsCpsCounter fpsCpsCounter = new FpsCpsCounter();
    public static class_304 configKeyBinding;
    public static class_304 resetCooldownKeyBinding;
    public static class_304 toggleContinuousKeyBinding;
    public static class_304 noRenderKeyBinding;
    public static class_304 noRenderTimerKeyBinding;
    public static class_304 noRenderInactiveKeyBinding;
    private int globalTickCounter = 0;
    private boolean wasAttackKeyPressedLastTick = false;
    private boolean wasUseKeyPressedLastTick = false;

    public ActionbarStorageClient() {}

    public static void init() {
        ActionbarStorageClient clientInstance = new ActionbarStorageClient();
        clientInstance.onInitializeClient();
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        new FullbrightModClient().onInitializeClient();
        new DeveloperModClient().onInitializeClient();
        new NaturalMotionBlurMod().onInitializeClient();

        savedConfig = StorageConfig.load();

        FpsManager.init();
        NoRenderEngine.init();
        SoundReducer.init();
        WindowFocusEvent.register(new MuteOnInactive());

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (client.method_1548() != null) {
                UUID selfUuid = getSelfUuid(client);
                if (selfUuid != null) {
                    ModServerClient.sendHeartbeatAsync(selfUuid);
                    ModServerClient.fetchUsersAsync();
                }
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            if (client.method_1548() != null) {
                UUID selfUuid = getSelfUuid(client);
                if (selfUuid != null) {
                    ModServerClient.sendLogoutAsync(selfUuid);
                }
            }
            ModPlayerTracker.clear();
        });

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            scheduler.shutdownNow();
        }));

        configKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Actionbar Config Megnyitása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, "Actionbar Storage Mod"));
        resetCooldownKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Cooldown Nullázása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_SEMICOLON, "Actionbar Storage Mod"));
        toggleContinuousKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Kesz Felirat Mod Valtas", class_3675.class_307.field_1668, GLFW.GLFW_KEY_APOSTROPHE, "Actionbar Storage Mod"));
        noRenderKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "3D Rendereles Ki/Be", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F6, "NoRender"));
        noRenderTimerKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "NoRender Idozito Ki/Be", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F8, "NoRender"));
        noRenderInactiveKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "NoRender Ablak Inaktivnal", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F8, "NoRender"));

        ActionbarReader.init();

        HudRenderCallback.EVENT.register(CustomHudRenderer::render);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            FpsManager.tick();
            NoRenderEngine.tick(client);

            globalTickCounter++;
            cloneManager.tick(globalTickCounter);
            ActionbarReader.handleTick(client);
            fpsCpsCounter.tick(client);

            if (globalTickCounter % 200 == 0 && client.method_1548() != null) {
                UUID selfUuid = getSelfUuid(client);
                if (selfUuid != null) {
                    ModServerClient.sendHeartbeatAsync(selfUuid);
                    ModServerClient.fetchUsersAsync();
                }
            }

            while (configKeyBinding.method_1436()) {
                if (savedConfig == null) savedConfig = StorageConfig.load();
                client.method_1507(new StorageConfigScreen(savedConfig));
            }

            while (noRenderKeyBinding.method_1436()) NoRenderEngine.toggle(client);
            while (noRenderTimerKeyBinding.method_1436()) NoRenderEngine.toggleTimer(client);
            while (noRenderInactiveKeyBinding.method_1436()) NoRenderEngine.toggleInactive(client);

            int activeSlot = client.field_1724.method_31548().field_7545;

            if (activeSlot >= 0 && activeSlot < 9 && getConfig().hudSlotsEnabled[activeSlot]) {
                while (resetCooldownKeyBinding.method_1436()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null) {
                        CooldownTracker.INSTANCE.resetCooldowns(settings.cooldownKey());
                    }
                }

                boolean isAttackPressedNow = client.field_1690.field_1886.method_1434();
                boolean isLeftClicked = client.field_1690.field_1886.method_1436() || (isAttackPressedNow && !wasAttackKeyPressedLastTick);
                if (isLeftClicked) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.leftCD() > 0) {
                        if (CooldownTracker.INSTANCE.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), false)) {
                            CooldownTracker.INSTANCE.registerLeftClick(settings.cooldownKey(), globalTickCounter, settings.leftCD());
                        }
                    }
                }
                wasAttackKeyPressedLastTick = isAttackPressedNow;

                boolean isUsePressedNow = client.field_1690.field_1904.method_1434();
                boolean isRightClicked = isUsePressedNow && !wasUseKeyPressedLastTick;
                if (isRightClicked) {
                    class_1799 offhandStack = client.field_1724.method_6079();
                    SlotSettings offhandSettings = getSettingsForItem(offhandStack);
                    boolean offhandUsed = false;
                    if (offhandSettings != null && offhandSettings.cooldownKey() != null && offhandSettings.rightCD() > 0) {
                        if (CooldownTracker.INSTANCE.isReady(offhandSettings.cooldownKey(), offhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                            CooldownTracker.INSTANCE.registerRightClick(offhandSettings.cooldownKey(), globalTickCounter, offhandSettings.rightCD());
                            offhandUsed = true;
                        }
                    }
                    if (!offhandUsed) {
                        SlotSettings mainhandSettings = getSlotSettings(activeSlot);
                        if (mainhandSettings != null && mainhandSettings.cooldownKey() != null && mainhandSettings.rightCD() > 0) {
                            if (mainhandSettings.cooldownKey().startsWith("minecraft:paper:581")) {
                                if (CooldownTracker.INSTANCE.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)
                                        && cloneManager.getActiveClonesCount() < 2) {
                                    CooldownTracker.INSTANCE.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                    cloneManager.spawnClone(globalTickCounter);
                                }
                            } else {
                                if (CooldownTracker.INSTANCE.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                    CooldownTracker.INSTANCE.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                }
                            }
                        }
                    }
                }
                wasUseKeyPressedLastTick = isUsePressedNow;
            } else {
                while (resetCooldownKeyBinding.method_1436()) {}
                wasAttackKeyPressedLastTick = false;
                wasUseKeyPressedLastTick = false;
            }
        });
    }

    private static UUID getSelfUuid(class_310 client) {
        if (client.method_1548() == null) return null;
        UUID uuid = client.method_1548().method_44717();
        if (uuid == null) {
            String username = client.method_1548().method_1676();
            if (username != null && !username.isEmpty()) {
                uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
            }
        }
        return uuid;
    }

    public static ActionbarStorageClient getInstance() {
        if (instance == null) {
            instance = new ActionbarStorageClient();
        }
        return instance;
    }

    public ManaManager getManaManager() { return this.manaManager; }
    public CloneManager getCloneManager() { return this.cloneManager; }
    public int getGlobalTickCounter() { return this.globalTickCounter; }
    public ScheduledExecutorService getScheduler() { return scheduler; }
    public FpsCpsCounter getFpsCpsCounter() { return fpsCpsCounter; }

    public static StorageConfig getConfig() {
        if (savedConfig == null) savedConfig = StorageConfig.load();
        return savedConfig;
    }

    public static SlotSettings getSlotSettings(int slot) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || slot < 0 || slot > 8) return null;
        return getSettingsForItem(client.field_1724.method_31548().method_5438(slot));
    }

    public static SlotSettings getSettingsForItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;
        StorageConfig config = getConfig();
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        int customModelData = 0;
        if (stack.method_7985() && stack.method_7969().method_10545("CustomModelData")) {
            customModelData = stack.method_7969().method_10550("CustomModelData");
        }
        String currentItemName = stack.method_7964().getString();
        String globalKey = itemId + ":" + customModelData;

        if (config.normalItems != null) {
            for (StorageConfig.ItemPreset preset : config.normalItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    return new SlotSettings(globalKey, currentItemName, preset.leftCD, preset.rightCD, preset.leftMana, preset.rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        if (config.leveledItems != null) {
            for (StorageConfig.LeveledItemPreset preset : config.leveledItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    int leftCd = preset.leftCD, rightCd = preset.rightCD, leftMana = preset.leftMana, rightMana = preset.rightMana;
                    if (preset.levels != null && currentItemName != null) {
                        for (StorageConfig.ItemLevel lvl : preset.levels) {
                            if (currentItemName.contains(lvl.levelNameIndicator)) {
                                leftCd = lvl.leftCD; rightCd = lvl.rightCD;
                                leftMana = lvl.leftMana; rightMana = lvl.rightMana;
                                break;
                            }
                        }
                    }
                    return new SlotSettings(globalKey, currentItemName, leftCd, rightCd, leftMana, rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        return null;
    }

    public record SlotSettings(String cooldownKey, String displayName, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {}
}