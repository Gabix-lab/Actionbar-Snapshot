package me.Gabix.soundreducer;

import me.Gabix.ActionbarStorageClient;
import me.Gabix.StorageConfig;
import me.Gabix.WindowFocusListener;
import net.minecraft.class_310;
import net.minecraft.class_3419;

public class MuteOnInactive implements WindowFocusListener {
    private double previousMasterVolume = -1.0;
    private boolean muted = false;

    @Override
    public void onFocusLost() {
        class_310 client = class_310.method_1551();
        StorageConfig config = ActionbarStorageClient.getConfig();
        if (config == null || !config.muteOnInactive) {
            return;
        }
        if (client.field_1690 != null) {
            double current = client.field_1690.method_45578(class_3419.field_15250).method_41753();
            if (current > 0.0) {
                previousMasterVolume = current;

                client.field_1690.method_45578(class_3419.field_15250).method_41748(0.0);

                if (client.method_1483() != null) {
                    client.method_1483().method_4881();
                }

                muted = true;
            }
        }
    }

    @Override
    public void onFocusGained() {
        if (muted) {
            class_310 client = class_310.method_1551();
            if (client.field_1690 != null && previousMasterVolume >= 0.0) {

                client.field_1690.method_45578(class_3419.field_15250).method_41748(previousMasterVolume);
                previousMasterVolume = -1.0;
                muted = false;
            }
        }
    }
}