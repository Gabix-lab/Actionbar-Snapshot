package me.Gabix.soundreducer;

import net.minecraft.class_310;

public class SoundReducer {
    private static boolean suppressed = false;

    public static void init() {
    }

    public static void onFocusChange(boolean focused) {
        class_310 client = class_310.method_1551();

        if (focused) {
            suppressed = false;
        } else {
            suppressed = true;
        }

        if (client != null && client.method_1483() != null) {
            client.method_1483().method_4876(client.field_1773.method_19418());
            if (suppressed) {
                client.method_1483().method_4881();
            }
        }
    }

    public static boolean isSuppressed() {
        return suppressed;
    }
}