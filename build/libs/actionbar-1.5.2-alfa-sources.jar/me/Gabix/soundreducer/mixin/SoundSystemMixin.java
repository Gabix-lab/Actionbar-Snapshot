package me.Gabix.soundreducer.mixin;

import me.Gabix.soundreducer.SoundReducer;
import net.minecraft.class_1140;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1140.class)
public class SoundSystemMixin {

    @Inject(method = "getSoundVolume", at = @At("HEAD"), cancellable = true)
    private void onGetSoundVolume(class_3419 category, CallbackInfoReturnable<Float> cir) {
        if (SoundReducer.isSuppressed()) {
            cir.setReturnValue(0.0f);
        }
    }
}