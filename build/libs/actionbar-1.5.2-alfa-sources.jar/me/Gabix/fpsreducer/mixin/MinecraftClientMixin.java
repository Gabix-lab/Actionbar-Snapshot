package me.Gabix.fpsreducer.mixin;

import me.Gabix.fpsreducer.FpsReducerLogic;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_310.class)
public class MinecraftClientMixin {

    @Shadow
    private native int getFramerateLimit();

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/MinecraftClient;getFramerateLimit()I"
            )
    )
    private int overrideFramerateLimit(class_310 instance) {
        if (FpsReducerLogic.isActive()) {
            return FpsReducerLogic.getTargetFps();
        }
        return this.getFramerateLimit();
    }
}