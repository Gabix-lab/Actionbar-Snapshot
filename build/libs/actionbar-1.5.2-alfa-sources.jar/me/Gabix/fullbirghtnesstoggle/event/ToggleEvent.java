package me.Gabix.fullbirghtnesstoggle.event;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7172;

public class ToggleEvent {
    private static final class_310 mc = class_310.method_1551();
    private static double originalGamma = -1.0;
    public static final double MAX_GAMMA = 100.0;
    private static boolean fullbrightActive = false;
    private static boolean startupDone = false;

    public static boolean isFullbrightEnabled() {
        return fullbrightActive;
    }

    public static void startupCheck() {
        if (startupDone) return;
        if (mc.field_1724 == null || mc.field_1690 == null) return;

        class_7172<Double> gammaOption = mc.field_1690.method_42473();
        double currentGamma = gammaOption.method_41753();

        if (originalGamma < 0.0) {
            originalGamma = currentGamma;
        }

        fullbrightActive = true;
        gammaOption.method_41748(MAX_GAMMA);
        startupDone = true;
    }

    public static void onHotkeyPress() {
        if (mc.field_1755 == null && mc.field_1690 != null && mc.field_1724 != null) {
            class_7172<Double> gammaOption = mc.field_1690.method_42473();
            double currentGamma = gammaOption.method_41753();

            if (originalGamma < 0.0) {
                originalGamma = currentGamma;
            }

            if (fullbrightActive) {
                gammaOption.method_41748(originalGamma);
                fullbrightActive = false;
            } else {
                originalGamma = Math.abs(currentGamma - MAX_GAMMA) > 0.1 ? currentGamma : originalGamma;
                gammaOption.method_41748(MAX_GAMMA);
                fullbrightActive = true;
            }

            String status = fullbrightActive ? "§aON" : "§cOFF";
            mc.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fFullbright: " + status), true);
        }
    }
}