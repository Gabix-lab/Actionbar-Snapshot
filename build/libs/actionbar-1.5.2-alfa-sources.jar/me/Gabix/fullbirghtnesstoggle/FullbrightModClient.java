package me.Gabix.fullbirghtnesstoggle;

import me.Gabix.fullbirghtnesstoggle.event.ToggleEvent;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class FullbrightModClient implements ClientModInitializer {
    private static class_304 fullbrightKeyBinding;
    private boolean fullbrightPressed = false;

    @Override
    public void onInitializeClient() {
        fullbrightKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Fullbright Ki/Be",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_G,
                "Fullbright"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            ToggleEvent.startupCheck();

            if (fullbrightKeyBinding.method_1434()) {
                if (!fullbrightPressed) {
                    fullbrightPressed = true;
                    ToggleEvent.onHotkeyPress();
                }
            } else {
                fullbrightPressed = false;
            }
        });
    }
}