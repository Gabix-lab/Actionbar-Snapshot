package me.Gabix.fullbirghtnesstoggle.mixin;

import me.Gabix.fullbirghtnesstoggle.event.ToggleEvent;
import net.minecraft.class_310;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_7172.class)
public class SimpleOptionMixin<T> {

    @Shadow
    T value;

    @SuppressWarnings("unchecked")
    @Inject(method = "getValue", at = @At("HEAD"), cancellable = true)
    private void forceGammaValue(CallbackInfoReturnable<T> cir) {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1690 != null) {
            class_7172<Double> gammaOption = client.field_1690.method_42473();
            if ((Object) this == (Object) gammaOption && value instanceof Double) {
                if (ToggleEvent.isFullbrightEnabled()) {
                    cir.setReturnValue((T) Double.valueOf(ToggleEvent.MAX_GAMMA));
                }
            }
        }
    }
}