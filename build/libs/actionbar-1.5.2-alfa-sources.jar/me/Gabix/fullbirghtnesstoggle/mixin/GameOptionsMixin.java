package me.Gabix.fullbirghtnesstoggle.mixin;

import net.minecraft.class_315;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_315.class)
public class GameOptionsMixin {

    @Shadow private class_7172<Double> gamma;
    private double gammaOriginalValue = 0.0;

    @Inject(method = "write", at = @At("HEAD"))
    private void onWriteHead(CallbackInfo ci) {
        if (gamma != null) {
            gammaOriginalValue = gamma.method_41753();
            if (gammaOriginalValue > 1.0) {
                gamma.method_41748(1.0);
            }
        }
    }

    @Inject(method = "write", at = @At("TAIL"))
    private void onWriteTail(CallbackInfo ci) {
        if (gamma != null && gammaOriginalValue > 1.0) {
            gamma.method_41748(gammaOriginalValue);
        }
    }
}