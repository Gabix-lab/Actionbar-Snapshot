package me.Gabix.developer;

import me.Gabix.ActionbarReader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class DeveloperModClient implements ClientModInitializer {
    private static class_304 readActionbarKeyBinding;
    private static class_304 readBossBarsKeyBinding;
    private static class_304 itemInfoKeyBinding;

    private boolean readActionbarPressed = false;
    private boolean readBossBarsPressed = false;
    private boolean itemInfoPressed = false;

    @Override
    public void onInitializeClient() {
        readActionbarKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Actionbar Nyers Beolvasása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_H, "Developer Tools"));
        readBossBarsKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "BossBar Név Beolvasása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_J, "Developer Tools"));
        itemInfoKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Item Info Megjelenítése", class_3675.class_307.field_1668, GLFW.GLFW_KEY_I, "Developer Tools"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            if (readActionbarKeyBinding.method_1434()) {
                if (!readActionbarPressed) {
                    readActionbarPressed = true;
                    ActionbarReader.handleReadActionbar(client);
                }
            } else {
                readActionbarPressed = false;
            }

            if (readBossBarsKeyBinding.method_1434()) {
                if (!readBossBarsPressed) {
                    readBossBarsPressed = true;
                    ActionbarReader.handleReadBossBars(client);
                }
            } else {
                readBossBarsPressed = false;
            }

            if (itemInfoKeyBinding.method_1434()) {
                if (!itemInfoPressed) {
                    itemInfoPressed = true;
                    ActionbarReader.handleItemInfo(client);
                }
            } else {
                itemInfoPressed = false;
            }
        });
    }
}