package me.Gabix.fireoverlay.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import me.Gabix.StorageConfig;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_757;

@SuppressWarnings("deprecation")
public class FireOverlayConfigScreen extends class_437 {
    private static final class_2960 FIRE_SPRITE_ID = new class_2960("minecraft", "block/fire_0");

    private final StorageConfig config;
    private final class_437 parent;

    private static final int SLIDER_WIDTH = 20;
    private static final int SLIDER_HEIGHT = 150;
    private static final int SLIDER_Y = 60;
    private int sliderX;

    private boolean dragging = false;

    public FireOverlayConfigScreen(StorageConfig config, class_437 parent) {
        super(class_2561.method_43470("Tűz Overlay Magasság"));
        this.config = config;
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.sliderX = this.field_22789 / 2 - SLIDER_WIDTH / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Kész"), button -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(this.parent);
            }
        }).method_46434(this.field_22789 / 2 - 40, SLIDER_Y + SLIDER_HEIGHT + 20, 80, 20).method_46431());
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (mouseX >= sliderX - 4 && mouseX <= sliderX + SLIDER_WIDTH + 4 &&
                    mouseY >= SLIDER_Y - 4 && mouseY <= SLIDER_Y + SLIDER_HEIGHT + 4) {
                dragging = true;
                updateValueFromMouse(mouseY);
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging) {
            updateValueFromMouse(mouseY);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    private void updateValueFromMouse(double mouseY) {
        double clampedY = Math.max(SLIDER_Y, Math.min(SLIDER_Y + SLIDER_HEIGHT, mouseY));
        double fraction = (clampedY - SLIDER_Y) / SLIDER_HEIGHT;
        int newValue = (int) Math.round((1.0 - fraction) * 100);
        config.fireOverlayHeight = Math.max(0, Math.min(100, newValue));
        config.save();
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);

        // --- PONTOS MINECRAFT ÉGÉS OVERLAY (NEM TORZÍTÓ ELTOLÁSSAL) ---
        if (config.fireOverlayHeight > 0 && this.field_22787 != null) {
            class_1058 fireSprite = class_310.method_1551()
                    .method_1549(class_1059.field_5275)
                    .apply(FIRE_SPRITE_ID);

            RenderSystem.setShader(class_757::method_34542);
            RenderSystem.setShaderTexture(0, class_1059.field_5275);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 0.9F);
            RenderSystem.enableBlend();

            matrices.method_22903();

            float heightPercent = config.fireOverlayHeight / 100.0F;

            // Fix textúra magasság (a képernyő 1.3-szorosa, hogy 100%-nál bőven felérjen)
            int fireWidth = (int) (this.field_22789 * 0.6F);
            int fireHeight = (int) (this.field_22790 * 1.3F);

            // Az Y pozíció eltolása:
            // 100%-nál a képernyő tetejéig ér (renderY = this.height - fireHeight)
            // 30%-nál pontosan a hotbar környékén bukkan csak ki alulról
            int maxOffset = fireHeight;
            int renderY = this.field_22790 - (int) (maxOffset * heightPercent);

            // 1. Bal oldali tűz
            class_332.method_25298(
                    matrices,
                    0, renderY,
                    0,
                    fireWidth, fireHeight,
                    fireSprite
            );

            // 2. Jobb oldali tűz (középen 1/5 átfedéssel)
            class_332.method_25298(
                    matrices,
                    this.field_22789 - fireWidth, renderY,
                    0,
                    fireWidth, fireHeight,
                    fireSprite
            );

            matrices.method_22909();
            RenderSystem.disableBlend();
        }

        // --- CÍM ---
        method_25300(matrices, this.field_22793, "Tűz Overlay Magasság", this.field_22789 / 2, 20, 0xFFFFFF);

        // --- CSÚSZKA ---
        int panelX = sliderX - 30;
        int panelY = SLIDER_Y - 10;
        int panelW = SLIDER_WIDTH + 60;
        int panelH = SLIDER_HEIGHT + 20;
        method_25294(matrices, panelX + 2, panelY + 2, panelX + panelW + 2, panelY + panelH + 2, 0x55000000);
        method_25294(matrices, panelX, panelY, panelX + panelW, panelY + panelH, 0xCC2D2D2D);

        method_25294(matrices, sliderX, SLIDER_Y, sliderX + SLIDER_WIDTH, SLIDER_Y + SLIDER_HEIGHT, 0xFF111111);
        int filledHeight = (int) (config.fireOverlayHeight / 100.0 * SLIDER_HEIGHT);
        int filledY = SLIDER_Y + SLIDER_HEIGHT - filledHeight;
        if (filledHeight > 0) {
            method_25296(matrices, sliderX + 1, filledY, sliderX + SLIDER_WIDTH - 1, SLIDER_Y + SLIDER_HEIGHT, 0xFFFF5500, 0xFFFF0000);
        }

        int handleY = SLIDER_Y + SLIDER_HEIGHT - filledHeight - 6;
        method_25294(matrices, sliderX - 6 + 1, handleY + 1, sliderX + SLIDER_WIDTH + 6 + 1, handleY + 12 + 1, 0x55000000);
        method_25294(matrices, sliderX - 6, handleY, sliderX + SLIDER_WIDTH + 6, handleY + 12, 0xFFFFFFFF);
        method_25294(matrices, sliderX - 5, handleY + 1, sliderX + SLIDER_WIDTH + 5, handleY + 11, 0xFF333333);
        String percentText = config.fireOverlayHeight + "%";
        int textWidth = this.field_22793.method_1727(percentText);
        this.field_22793.method_1720(matrices, percentText, sliderX + SLIDER_WIDTH / 2 - textWidth / 2, handleY + 2, 0xFFFF5555);

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}