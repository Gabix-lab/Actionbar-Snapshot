package me.Gabix.tracker;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;

public class ModPlayerTracker {
    private static final Set<UUID> MOD_USERS = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public static void registerUser(UUID uuid) {
        if (uuid != null) {
            MOD_USERS.add(uuid);
        }
    }

    public static void updateUsers(Set<UUID> newUsers) {
        MOD_USERS.clear();
        if (newUsers != null) {
            MOD_USERS.addAll(newUsers);
        }
    }

    public static boolean usesMod(UUID uuid) {
        return MOD_USERS.contains(uuid);
    }

    public static void clear() {
        MOD_USERS.clear();
    }
}