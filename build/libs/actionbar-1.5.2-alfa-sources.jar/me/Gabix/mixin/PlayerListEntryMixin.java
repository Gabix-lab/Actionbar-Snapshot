package me.Gabix.mixin;

import me.Gabix.tracker.ModPlayerTracker;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_355;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_355.class)
public class PlayerListEntryMixin {

    private static final class_2960 DEFAULT_FONT = new class_2960("minecraft", "default");

    @Inject(method = "getPlayerName", at = @At("HEAD"), cancellable = true)
    private void overridePlayerName(class_640 entry, CallbackInfoReturnable<class_2561> cir) {
        if (entry == null) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        boolean isSelf = entry.method_2966().getId().equals(client.field_1724.method_5667());
        boolean isModUser = ModPlayerTracker.usesMod(entry.method_2966().getId());

        // Ha a játékos saját maga, VAGY a külső webszerver szerint mod-használó
        if (isSelf || isModUser) {
            class_2561 displayName = entry.method_2971();
            if (displayName == null) {
                displayName = class_2561.method_43470(entry.method_2966().getName());
            }

            String raw = displayName.getString();

            if (!raw.contains("\uE001")) {
                class_2583 iconStyle = class_2583.field_24360.method_27704(DEFAULT_FONT).method_36139(0xFFFFFF);
                class_5250 iconPrefix = class_2561.method_43470("\uE001 ").method_10862(iconStyle);

                class_5250 finalTabName = class_2561.method_43473();
                finalTabName.method_10852(iconPrefix);
                finalTabName.method_10852(displayName);

                cir.setReturnValue(finalTabName);
            }
        }
    }
}