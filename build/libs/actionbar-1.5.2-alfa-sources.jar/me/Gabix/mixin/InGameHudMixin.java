package me.Gabix.mixin;

import me.Gabix.ActionbarStorageClient;
import me.Gabix.CloneManager;
import me.Gabix.CooldownTracker;
import me.Gabix.ManaManager;
import me.Gabix.StorageConfig;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void renderCustomHud(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690.field_1842 || client.field_1772 == null || client.field_1724 == null) return;

        StorageConfig config = ActionbarStorageClient.getConfig();
        class_1657 player = client.field_1724;
        int globalTick = ActionbarStorageClient.getInstance().getGlobalTickCounter();
        CloneManager cloneManager = ActionbarStorageClient.getInstance().getCloneManager();

        for (int i = 0; i < 9; i++) {
            if (!config.hudSlotsEnabled[i]) continue;

            int slotX = config.hudSlotsX[i];
            int slotY = config.hudSlotsY[i];
            float scale = config.hudSlotsScale[i];
            int slotSize = (int) (18 * scale);

            class_329.method_25294(matrices, slotX, slotY, slotX + slotSize, slotY + slotSize, 0x80000000);

            if (i == player.method_31548().field_7545) {
                class_329.method_25294(matrices, slotX, slotY, slotX + slotSize, slotY + 1, 0xFFFFFFFF);
                class_329.method_25294(matrices, slotX, slotY + slotSize - 1, slotX + slotSize, slotY + slotSize, 0xFFFFFFFF);
                class_329.method_25294(matrices, slotX, slotY, slotX + 1, slotY + slotSize, 0xFFFFFFFF);
                class_329.method_25294(matrices, slotX + slotSize - 1, slotY, slotX + slotSize, slotY + slotSize, 0xFFFFFFFF);
            }

            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                matrices.method_22903();
                matrices.method_46416(slotX + 1, slotY + 1, 0);
                matrices.method_22905(scale, scale, 1.0f);
                client.method_1480().method_4023(matrices, stack, 0, 0);
                client.method_1480().method_4025(matrices, client.field_1772, stack, 0, 0);
                matrices.method_22909();
            }

            ActionbarStorageClient.SlotSettings settings = ActionbarStorageClient.getSlotSettings(i);
            if (settings != null && settings.cooldownKey() != null) {
                String leftStatus = getStatusText(settings.cooldownKey(), settings.leftCD(), false, globalTick);
                String rightStatus = getStatusText(settings.cooldownKey(), settings.rightCD(), true, globalTick);
                String fullStatusText = leftStatus + " §f| " + rightStatus;
                client.field_1772.method_1720(matrices, fullStatusText, slotX + slotSize + 4, slotY + (int)(5 * scale), 0xFFFFFF);

                if (settings.cooldownKey().startsWith("minecraft:paper:581") && cloneManager != null && cloneManager.getActiveClonesCount() >= 2) {
                    int nextExpiry = cloneManager.getNextExpiryTick();
                    int remTicks = Math.max(0, nextExpiry - globalTick);
                    float secondsLeft = remTicks / 20.0f;
                    String foglaltStr = "§cFOGLALT §7(" + String.format("%.1f", secondsLeft) + "s)";
                    client.field_1772.method_1720(matrices, foglaltStr, slotX + slotSize + 4, slotY + (int)(14 * scale), 0xFFFFFF);
                }
            } else {
                client.field_1772.method_1720(matrices, "§7- §f| §7-", slotX + slotSize + 4, slotY + (int)(5 * scale), 0xFFFFFF);
            }
        }

        ManaManager manaManager = ActionbarStorageClient.getInstance().getManaManager();

        if (config.showMana) {
            matrices.method_22903();
            matrices.method_46416(config.manaX, config.manaY, 0);
            matrices.method_22905(config.manaScale, config.manaScale, 1.0f);
            String manaText = String.format("§bMana: %d", manaManager.getCurrentMana());
            client.field_1772.method_1720(matrices, manaText, 0, 0, 0xFFFFFF);
            matrices.method_22909();
        }

        if (config.showDamage) {
            matrices.method_22903();
            matrices.method_46416(config.damageX, config.damageY, 0);
            matrices.method_22905(config.damageScale, config.damageScale, 1.0f);
            int targetDmg = config.getTargetBossDamage();
            String targetStr = (targetDmg == Integer.MAX_VALUE) ? "§f§7-" : String.valueOf(targetDmg);
            int currentDmg = manaManager.getCurrentDamage();

            String damageColor;
            if (currentDmg <= 0) {
                damageColor = "§7";
            } else if (targetDmg != Integer.MAX_VALUE && currentDmg >= targetDmg) {
                damageColor = "§a";
            } else {
                damageColor = "§f";
            }

            String damageText = "§fSebzés: " + damageColor + currentDmg + " §7/ §e" + targetStr;
            client.field_1772.method_1720(matrices, damageText, 0, 0, 0xFFFFFF);
            matrices.method_22909();
        }
    }

    @Unique
    private String getStatusText(String key, int cooldownTicks, boolean isRight, int currentTick) {
        if (cooldownTicks <= 0) {
            return "§7-";
        }
        int expiry = isRight ? CooldownTracker.INSTANCE.getRightExpiry(key) : CooldownTracker.INSTANCE.getLeftExpiry(key);
        if (expiry > currentTick) {
            double remainingSec = (expiry - currentTick) / 20.0;
            String color = isRight ? "§d" : "§e";
            return String.format("%s%.1fs", color, remainingSec);
        }
        return "§akész";
    }
}