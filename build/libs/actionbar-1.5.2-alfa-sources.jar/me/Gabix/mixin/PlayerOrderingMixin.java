package me.Gabix.mixin;

import me.Gabix.tracker.ModPlayerTracker;
import net.minecraft.class_355;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Comparator;

@Mixin(class_355.class)
public class PlayerOrderingMixin {

    @Shadow
    @Final
    @Mutable
    private static Comparator<class_640> ENTRY_ORDERING;

    @Inject(method = "<clinit>", at = @At("RETURN"))
    private static void overrideOrdering(CallbackInfo ci) {
        Comparator<class_640> original = ENTRY_ORDERING;

        ENTRY_ORDERING = (entry1, entry2) -> {
            boolean user1HasMod = ModPlayerTracker.usesMod(entry1.method_2966().getId());
            boolean user2HasMod = ModPlayerTracker.usesMod(entry2.method_2966().getId());

            if (user1HasMod && !user2HasMod) return -1;
            if (!user1HasMod && user2HasMod) return 1;

            return original.compare(entry1, entry2);
        };
    }
}