package me.Gabix.mixin;

import me.Gabix.tracker.ModPlayerTracker;
import net.minecraft.class_2561;
import net.minecraft.class_355;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_355.class)
public class PlayerListHudMixin {

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void addIconToTabName(class_640 entry, CallbackInfoReturnable<class_2561> cir) {
        if (ModPlayerTracker.usesMod(entry.method_2966().getId())) {
            class_2561 originalName = cir.getReturnValue();
            class_2561 baseName = (originalName != null) ? originalName : class_2561.method_43470(entry.method_2966().getName());

            class_5250 customName = class_2561.method_43470("\uE001 ").method_10852(baseName);
            cir.setReturnValue(customName);
        }
    }
}