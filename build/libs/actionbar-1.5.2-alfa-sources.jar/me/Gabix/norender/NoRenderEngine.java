package me.Gabix.norender;

import me.Gabix.ActionbarStorageClient;
import me.Gabix.StorageConfig;
import me.Gabix.WindowFocusEvent;
import me.Gabix.WindowFocusListener;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class NoRenderEngine implements WindowFocusListener {
    public static boolean enabled = false;
    private static boolean isFocused = true;
    private static int noRenderIdleTicks = 0;
    private static double lastX, lastY, lastZ;
    private static float lastYaw, lastPitch;

    public static void init() {
        WindowFocusEvent.register(new NoRenderEngine());
    }

    @Override
    public void onFocusGained() {
        isFocused = true;
        noRenderIdleTicks = 0;
        if (enabled) {
            enabled = false;
            class_746 player = class_310.method_1551().field_1724;
            if (player != null) {
                player.method_7353(class_2561.method_43470("§7[GabixMod] §fAblak aktív - 3D Renderelés §aBEKAPCSOLVA"), true);
            }
        }
    }

    @Override
    public void onFocusLost() {
        isFocused = false;
        StorageConfig config = ActionbarStorageClient.getConfig();
        if (config.noRenderOnInactive && !enabled) {
            enabled = true;
            class_746 player = class_310.method_1551().field_1724;
            if (player != null) {
                player.method_7353(class_2561.method_43470("§7[GabixMod] §fAblak inaktív - 3D Renderelés §cKIKAPCSOLVA"), true);
            }
        }
    }

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) return;

        StorageConfig config = ActionbarStorageClient.getConfig();
        handleNoRenderTimer(client, config, isFocused, hasPlayerMoved(client, player));

        lastX = player.method_23317();
        lastY = player.method_23318();
        lastZ = player.method_23321();
        lastYaw = player.method_36454();
        lastPitch = player.method_36455();
    }

    public static void toggle(class_310 client) {
        enabled = !enabled;
        noRenderIdleTicks = 0;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                    class_2561.method_43470("§7[GabixMod] §f3D Renderelés: " + (enabled ? "§cKIKAPCSOLVA" : "§aBEKAPCSOLVA")),
                    true);
        }
    }

    public static void toggleTimer(class_310 client) {
        StorageConfig config = ActionbarStorageClient.getConfig();
        config.noRenderTimerEnabled = !config.noRenderTimerEnabled;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fNoRender Időzítő: " +
                    (config.noRenderTimerEnabled ? "§aBE" : "§cKI")), true);
        }
        config.save();
    }

    public static void toggleInactive(class_310 client) {
        StorageConfig config = ActionbarStorageClient.getConfig();
        config.noRenderOnInactive = !config.noRenderOnInactive;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fNoRender Ablak Inaktívnál: " +
                    (config.noRenderOnInactive ? "§aBE" : "§cKI")), true);
        }
        config.save();
    }

    private static void handleNoRenderTimer(class_310 client, StorageConfig config, boolean windowFocused, boolean playerMoved) {
        if (!config.noRenderTimerEnabled) {
            noRenderIdleTicks = 0;
            return;
        }
        if (!playerMoved && windowFocused) {
            int maxIdleTicks = ((config.noRenderMinutes * 60) + config.noRenderSeconds) * 20;
            if (maxIdleTicks == 0 || noRenderIdleTicks >= maxIdleTicks) {
                if (!enabled) {
                    enabled = true;
                    if (client.field_1724 != null) {
                        client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fNoRender Időzítő: §c3D Renderelés KIKAPCSOLVA"), true);
                    }
                }
            } else {
                noRenderIdleTicks++;
            }
        } else {
            if (enabled && windowFocused) {
                enabled = false;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fNoRender Időzítő: §a3D Renderelés BEKAPCSOLVA"), true);
                }
            }
            noRenderIdleTicks = 0;
        }
    }

    private static boolean hasPlayerMoved(class_310 client, class_746 player) {
        if (player.method_23317() != lastX || player.method_23318() != lastY || player.method_23321() != lastZ) return true;
        if (player.method_36454() != lastYaw || player.method_36455() != lastPitch) return true;
        var options = client.field_1690;
        return options.field_1894.method_1434() || options.field_1881.method_1434() ||
                options.field_1913.method_1434() || options.field_1849.method_1434() ||
                options.field_1903.method_1434() || options.field_1832.method_1434() ||
                options.field_1886.method_1434() || options.field_1904.method_1434();
    }

    public static void onUserInput() {
        noRenderIdleTicks = 0;
    }
}