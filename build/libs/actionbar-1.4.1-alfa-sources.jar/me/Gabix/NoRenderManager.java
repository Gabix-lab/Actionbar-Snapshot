package me.Gabix;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class NoRenderManager {
    public static boolean enabled = false;
    private static int idleTicksCount = 0;
    private static double lastX, lastY, lastZ;
    private static float lastYaw, lastPitch;

    public static void init(StorageConfig config) {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            while (ActionbarStorageClient.noRenderKeyBinding.method_1436()) {
                toggleNoRender(client);
            }
            if (config.noRenderTimerEnabled) {
                handleIdleDetection(client, config);
            } else {
                idleTicksCount = 0;
            }
        });
    }

    private static void handleIdleDetection(class_310 client, StorageConfig config) {
        class_746 player = client.field_1724;
        if (player == null) return;
        boolean moved = hasPlayerMoved(client, player);
        if (moved) {
            idleTicksCount = 0;
            if (enabled) {
                enabled = false;
                player.method_7353(class_2561.method_43470("§7[GabixMod] §fAktivitás érzékelve - 3D Renderelés §aBEKAPCSOLVA"), true);
            }
        } else {
            idleTicksCount++;
            int maxIdleTicks = ((config.noRenderMinutes * 60) + config.noRenderSeconds) * 20;
            if (maxIdleTicks > 0 && idleTicksCount >= maxIdleTicks && !enabled) {
                enabled = true;
                player.method_7353(class_2561.method_43470("§7[GabixMod] §fInaktivitás (" + config.noRenderMinutes + "m " + config.noRenderSeconds + "s) - 3D Renderelés §cKIKAPCSOLVA"), true);
            }
        }
        lastX = player.method_23317();
        lastY = player.method_23318();
        lastZ = player.method_23321();
        lastYaw = player.method_36454();
        lastPitch = player.method_36455();
    }

    private static boolean hasPlayerMoved(class_310 client, class_746 player) {
        if (player.method_23317() != lastX || player.method_23318() != lastY || player.method_23321() != lastZ) return true;
        if (player.method_36454() != lastYaw || player.method_36455() != lastPitch) return true;
        if (client.field_1690.field_1894.method_1434() || client.field_1690.field_1881.method_1434() ||
                client.field_1690.field_1913.method_1434() || client.field_1690.field_1849.method_1434() ||
                client.field_1690.field_1903.method_1434() || client.field_1690.field_1832.method_1434() ||
                client.field_1690.field_1886.method_1434() || client.field_1690.field_1904.method_1434()) {
            return true;
        }
        return false;
    }

    private static void toggleNoRender(class_310 client) {
        enabled = !enabled;
        idleTicksCount = 0;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                    class_2561.method_43470("§7[GabixMod] §f3D Renderelés: " + (enabled ? "§cKIKAPCSOLVA" : "§aBEKAPCSOLVA")),
                    true
            );
        }
    }
}