package me.Gabix;

import net.minecraft.class_310;

public class FullbrightManager {
    public static void tick(class_310 client) {
        // A FullbrightMixin kezeli a fényerőt rendszerszinten!
    }
}