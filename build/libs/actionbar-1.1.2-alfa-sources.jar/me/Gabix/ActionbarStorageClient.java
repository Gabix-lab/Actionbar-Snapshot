package me.Gabix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

public class ActionbarStorageClient implements ClientModInitializer {
    private static ActionbarStorageClient instance;
    private static StorageConfig savedConfig;
    private static class_304 configKeyBinding;
    private static class_304 resetCooldownKeyBinding;

    private ManaManager manaManager;
    private CloneManager cloneManager;
    private CooldownTracker cooldownTracker;
    private int globalTickCounter = 0;

    @Override
    public void onInitializeClient() {
        instance = this;
        savedConfig = StorageConfig.load();
        this.manaManager = new ManaManager();
        this.cloneManager = new CloneManager();
        this.cooldownTracker = new CooldownTracker();

        ActionbarReader.init();

        configKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.actionbarstorage.config",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.actionbarstorage"
        ));

        resetCooldownKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.actionbarstorage.reset",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_SEMICOLON,
                "category.actionbarstorage"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            globalTickCounter++;
            cloneManager.tick(globalTickCounter);
            ActionbarReader.handleTick(client);

            while (configKeyBinding.method_1436()) {
                if (savedConfig == null) {
                    savedConfig = StorageConfig.load();
                }
                client.method_1507(new StorageConfigScreen(savedConfig));
            }

            int activeSlot = client.field_1724.method_31548().field_7545;

            if (activeSlot >= 0 && activeSlot < 9 && getConfig().hudSlotsEnabled[activeSlot]) {

                while (resetCooldownKeyBinding.method_1436()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null) {
                        cooldownTracker.resetCooldowns(settings.cooldownKey());
                    }
                }

                boolean isLeftClicked = client.field_1690.field_1886.method_1436() || (client.field_1690.field_1886.method_1434() && client.field_1771 == 0);
                if (isLeftClicked) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.leftCD() > 0) {
                        if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), false)) {
                            cooldownTracker.registerLeftClick(settings.cooldownKey(), globalTickCounter, settings.leftCD());
                        }
                    }
                }

                if (client.field_1690.field_1904.method_1434() || client.field_1690.field_1904.method_1436()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.rightCD() > 0) {
                        if (settings.cooldownKey().startsWith("minecraft:paper:581")) {
                            if (cloneManager.getActiveClonesCount() < 2) {
                                if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                    cooldownTracker.registerRightClick(settings.cooldownKey(), globalTickCounter, settings.rightCD());
                                    cloneManager.spawnClone(globalTickCounter);
                                }
                            }
                        } else {
                            if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                cooldownTracker.registerRightClick(settings.cooldownKey(), globalTickCounter, settings.rightCD());
                            }
                        }
                    }
                }
            } else {
                while (resetCooldownKeyBinding.method_1436()) {}
            }
        });
    }

    public static ActionbarStorageClient getInstance() {
        if (instance == null) {
            instance = new ActionbarStorageClient();
        }
        return instance;
    }

    public ManaManager getManaManager() { return this.manaManager; }
    public CloneManager getCloneManager() { return this.cloneManager; }
    public CooldownTracker getCooldownTracker() { return this.cooldownTracker; }
    public int getGlobalTickCounter() { return this.globalTickCounter; }

    public static StorageConfig getConfig() {
        if (savedConfig == null) {
            savedConfig = StorageConfig.load();
        }
        return savedConfig;
    }

    public static SlotSettings getSlotSettings(int slot) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || slot < 0 || slot > 8) return null;
        class_1799 stack = client.field_1724.method_31548().method_5438(slot);
        return getSettingsForItem(stack);
    }

    public static SlotSettings getSettingsForItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;

        StorageConfig config = getConfig();
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        int customModelData = 0;
        if (stack.method_7985() && stack.method_7969().method_10545("CustomModelData")) {
            customModelData = stack.method_7969().method_10550("CustomModelData");
        }

        String currentItemName = stack.method_7964().getString();
        String globalKey = itemId + ":" + customModelData;

        if (config.normalItems != null) {
            for (StorageConfig.ItemPreset preset : config.normalItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    return new SlotSettings(globalKey, currentItemName, preset.leftCD, preset.rightCD, preset.leftMana, preset.rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }

        if (config.leveledItems != null) {
            for (StorageConfig.LeveledItemPreset preset : config.leveledItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    int leftCdTicks = preset.leftCD;
                    int rightCdTicks = preset.rightCD;
                    int leftMana = preset.leftMana;
                    int rightMana = preset.rightMana;

                    if (preset.levels != null && currentItemName != null) {
                        for (StorageConfig.ItemLevel lvl : preset.levels) {
                            if (currentItemName.contains(lvl.levelNameIndicator)) {
                                leftCdTicks = lvl.leftCD;
                                rightCdTicks = lvl.rightCD;
                                leftMana = lvl.leftMana;
                                rightMana = lvl.rightMana;
                                break;
                            }
                        }
                    }
                    return new SlotSettings(globalKey, currentItemName, leftCdTicks, rightCdTicks, leftMana, rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        return null;
    }

    public record SlotSettings(String cooldownKey, String displayName, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {}
}