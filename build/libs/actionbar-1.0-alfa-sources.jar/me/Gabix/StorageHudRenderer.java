package me.Gabix;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_918;

public class StorageHudRenderer {
    public static void render(class_4587 matrices, StorageConfig config, CooldownTracker tracker, ManaManager manaManager, int globalTickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_327 textRenderer = client.field_1772;
        class_918 itemRenderer = client.method_1480();
        class_1661 inventory = client.field_1724.method_31548();
        int height = client.method_22683().method_4502();

        int startX = 5, slotSize = 20;
        int totalHotbarHeight = 9 * slotSize;
        int startY = (height - totalHotbarHeight) / 2;

        CloneManager cloneManager = ActionbarStorageClient.getInstance().getCloneManager();

        for (int i = 0; i < 9; i++) {
            if (!config.hudSlotsEnabled[i]) continue;

            int slotY = startY + (i * slotSize);
            class_1799 stack = inventory.method_5438(i);

            class_332.method_25294(matrices, startX, slotY, startX + slotSize, slotY + slotSize, 0x66000000);

            if (inventory.field_7545 == i) {
                class_332.method_25294(matrices, startX, slotY, startX + slotSize, slotY + 1, 0xFFFFFFFF);
                class_332.method_25294(matrices, startX, slotY + slotSize - 1, startX + slotSize, slotY + slotSize, 0xFFFFFFFF);
                class_332.method_25294(matrices, startX, slotY, startX + 1, slotY + slotSize, 0xFFFFFFFF);
                class_332.method_25294(matrices, startX + slotSize - 1, slotY, startX + slotSize, slotY + slotSize, 0xFFFFFFFF);
            }

            if (!stack.method_7960()) {
                itemRenderer.method_4023(matrices, stack, startX + 2, slotY + 2);
                itemRenderer.method_4025(matrices, textRenderer, stack, startX + 2, slotY + 2);
            }

            ActionbarStorageClient.SlotSettings settings = ActionbarStorageClient.getSlotSettings(i);
            if (settings != null) {
                String key = settings.cooldownKey();
                if (key != null) {

                    if (key.startsWith("minecraft:paper:581") && cloneManager != null && cloneManager.getActiveClonesCount() >= 2) {
                        int nextExpiry = cloneManager.getNextExpiryTick();
                        int remTicks = Math.max(0, nextExpiry - globalTickCounter);
                        float secondsLeft = remTicks / 20.0f;

                        String foglaltStr = "§cFOGLALT §7(" + String.format("%.1f", secondsLeft) + ")";
                        textRenderer.method_1720(matrices, foglaltStr, startX + slotSize + 4, slotY + 6, 0xFFFFFF);
                        continue;
                    }

                    String leftStr = "§7-";
                    String rightStr = "§7-";

                    int leftExpiry = tracker.getLeftExpiry(key);
                    int rightExpiry = tracker.getRightExpiry(key);

                    if (settings.leftCD() > 0) {
                        if (leftExpiry > globalTickCounter) {
                            int remTicks = leftExpiry - globalTickCounter;
                            leftStr = "§e" + String.format("%.1f", remTicks / 20.0f);
                        } else {
                            leftStr = "§akész";
                        }
                    }

                    if (settings.rightCD() > 0) {
                        if (rightExpiry > globalTickCounter) {
                            int remTicks = rightExpiry - globalTickCounter;
                            rightStr = "§d" + String.format("%.1f", remTicks / 20.0f);
                        } else {
                            rightStr = "§akész";
                        }
                    }

                    textRenderer.method_1720(matrices, leftStr + " §f| " + rightStr, startX + slotSize + 4, slotY + 6, 0xFFFFFF);
                }
            } else {
                textRenderer.method_1720(matrices, "§7- §f| §7-", startX + slotSize + 4, slotY + 6, 0xFFFFFF);
            }
        }

        textRenderer.method_1720(matrices, "Mana: " + manaManager.getCurrentMana(), startX, startY + totalHotbarHeight + 4, 0x55FFFF);
    }
}