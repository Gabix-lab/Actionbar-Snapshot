package me.Gabix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

public class ActionbarStorageClient implements ClientModInitializer {
    private static ActionbarStorageClient instance;
    private static StorageConfig savedConfig;

    public static class_304 configKeyBinding;
    public static class_304 resetCooldownKeyBinding;
    public static class_304 readActionbarKeyBinding;
    public static class_304 readBossBarsKeyBinding;
    public static class_304 toggleContinuousKeyBinding;
    public static class_304 noRenderKeyBinding;
    public static class_304 noRenderTimerKeyBinding;
    public static class_304 itemInfoKeyBinding;
    public static class_304 noRenderInactiveKeyBinding;

    private ManaManager manaManager;
    private CloneManager cloneManager;
    private int globalTickCounter = 0;
    private boolean wasAttackKeyPressedLastTick = false;
    private boolean wasUseKeyPressedLastTick = false;

    public ActionbarStorageClient() {
        this.manaManager = new ManaManager();
        this.cloneManager = new CloneManager();
    }

    @Override
    public void onInitializeClient() {
        instance = this;
        savedConfig = StorageConfig.load();

        configKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Actionbar Config Megnyitása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, "Actionbar Storage Mod"));
        readActionbarKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Actionbar Nyers Beolvasása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_H, "Actionbar Storage Mod"));
        readBossBarsKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "BossBar Név Beolvasása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_J, "Actionbar Storage Mod"));
        resetCooldownKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Cooldown Nullázása", class_3675.class_307.field_1668, GLFW.GLFW_KEY_SEMICOLON, "Actionbar Storage Mod"));
        toggleContinuousKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Kész Felirat Mód Váltás", class_3675.class_307.field_1668, GLFW.GLFW_KEY_APOSTROPHE, "Actionbar Storage Mod"));
        noRenderKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "3D Renderelés Ki/Be", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F6, "Actionbar Storage Mod"));
        noRenderTimerKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "NoRender Időzítő Ki/Be", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F7, "Actionbar Storage Mod"));
        noRenderInactiveKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "NoRender Ablak Inaktívnál", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F8, "Actionbar Storage Mod"));
        itemInfoKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Item Info Megjelenítése", class_3675.class_307.field_1668, GLFW.GLFW_KEY_I, "Actionbar Storage Mod"));

        ActionbarReader.init();
        NoRenderManager.init(savedConfig);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            globalTickCounter++;
            cloneManager.tick(globalTickCounter);
            ActionbarReader.handleTick(client);

            while (configKeyBinding.method_1436()) {
                if (savedConfig == null) savedConfig = StorageConfig.load();
                client.method_1507(new StorageConfigScreen(savedConfig));
            }

            while (noRenderTimerKeyBinding.method_1436()) {
                savedConfig.noRenderTimerEnabled = !savedConfig.noRenderTimerEnabled;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fNoRender Időzítő: " +
                            (savedConfig.noRenderTimerEnabled ? "§aBE" : "§cKI")), true);
                }
                savedConfig.save();
            }

            while (noRenderInactiveKeyBinding.method_1436()) {
                savedConfig.noRenderOnInactive = !savedConfig.noRenderOnInactive;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fNoRender Ablak Inaktívnál: " +
                            (savedConfig.noRenderOnInactive ? "§aBE" : "§cKI")), true);
                }
                savedConfig.save();
            }

            while (itemInfoKeyBinding.method_1436()) {
                class_1799 held = client.field_1724.method_6047();
                if (held.method_7960()) {
                    client.field_1724.method_7353(class_2561.method_43470("§c[Item Info] Nincs tárgy a kezedben!"), false);
                } else {
                    String name = held.method_7964().getString();
                    client.field_1724.method_7353(class_2561.method_43470("§a[Item Info] §fNév: §e" + name), false);

                    int cmd = 0;
                    boolean hasCmd = false;
                    if (held.method_7985() && held.method_7969().method_10545("CustomModelData")) {
                        cmd = held.method_7969().method_10550("CustomModelData");
                        hasCmd = true;
                    }
                    if (hasCmd) {
                        client.field_1724.method_7353(class_2561.method_43470("§a[Item Info] §fCMD: §b" + cmd), false);
                    } else {
                        client.field_1724.method_7353(class_2561.method_43470("§a[Item Info] §fCMD: §7nincs"), false);
                    }

                    if (held.method_7985() && held.method_7969().method_10545("display")) {
                        class_2487 display = held.method_7969().method_10562("display");
                        if (display.method_10573("Lore", 9)) {
                            class_2499 loreList = display.method_10554("Lore", 8);
                            client.field_1724.method_7353(class_2561.method_43470("§a[Item Info] §fLore:"), false);
                            for (int i = 0; i < loreList.size(); i++) {
                                String jsonText = loreList.method_10608(i);
                                try {
                                    class_2561 line = class_2561.class_2562.method_10877(jsonText);
                                    if (line != null) {
                                        client.field_1724.method_7353(class_2561.method_43470("§7- §f").method_10852(line), false);
                                    } else {
                                        client.field_1724.method_7353(class_2561.method_43470("§7- §c[hibás JSON]"), false);
                                    }
                                } catch (Exception e) {
                                    client.field_1724.method_7353(class_2561.method_43470("§7- §c[hibás formátum]"), false);
                                }
                            }
                        } else {
                            client.field_1724.method_7353(class_2561.method_43470("§a[Item Info] §fLore: §7nincs"), false);
                        }
                    } else {
                        client.field_1724.method_7353(class_2561.method_43470("§a[Item Info] §fLore: §7nincs"), false);
                    }
                }
            }

            int activeSlot = client.field_1724.method_31548().field_7545;

            if (activeSlot >= 0 && activeSlot < 9 && getConfig().hudSlotsEnabled[activeSlot]) {
                while (resetCooldownKeyBinding.method_1436()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null) {
                        CooldownTracker.INSTANCE.resetCooldowns(settings.cooldownKey());
                    }
                }

                boolean isAttackPressedNow = client.field_1690.field_1886.method_1434();
                boolean isLeftClicked = client.field_1690.field_1886.method_1436() || (isAttackPressedNow && !wasAttackKeyPressedLastTick);
                if (isLeftClicked) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.leftCD() > 0) {
                        if (CooldownTracker.INSTANCE.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), false)) {
                            CooldownTracker.INSTANCE.registerLeftClick(settings.cooldownKey(), globalTickCounter, settings.leftCD());
                        }
                    }
                }
                wasAttackKeyPressedLastTick = isAttackPressedNow;

                boolean isUsePressedNow = client.field_1690.field_1904.method_1434();
                if (isUsePressedNow) {
                    class_1799 offhandStack = client.field_1724.method_6079();
                    SlotSettings offhandSettings = getSettingsForItem(offhandStack);
                    boolean offhandUsed = false;
                    if (offhandSettings != null && offhandSettings.cooldownKey() != null && offhandSettings.rightCD() > 0) {
                        if (CooldownTracker.INSTANCE.isReady(offhandSettings.cooldownKey(), offhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                            CooldownTracker.INSTANCE.registerRightClick(offhandSettings.cooldownKey(), globalTickCounter, offhandSettings.rightCD());
                            offhandUsed = true;
                        }
                    }
                    if (!offhandUsed) {
                        SlotSettings mainhandSettings = getSlotSettings(activeSlot);
                        if (mainhandSettings != null && mainhandSettings.cooldownKey() != null && mainhandSettings.rightCD() > 0) {
                            if (mainhandSettings.cooldownKey().startsWith("minecraft:paper:581")) {
                                if (CooldownTracker.INSTANCE.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)
                                        && cloneManager.getActiveClonesCount() < 2) {
                                    CooldownTracker.INSTANCE.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                    cloneManager.spawnClone(globalTickCounter);
                                }
                            } else {
                                if (CooldownTracker.INSTANCE.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                    CooldownTracker.INSTANCE.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                }
                            }
                        }
                    }
                }
                wasUseKeyPressedLastTick = isUsePressedNow;
            } else {
                while (resetCooldownKeyBinding.method_1436()) {}
                wasAttackKeyPressedLastTick = false;
                wasUseKeyPressedLastTick = false;
            }
        });
    }

    public static ActionbarStorageClient getInstance() {
        if (instance == null) {
            instance = new ActionbarStorageClient();
        }
        return instance;
    }

    public ManaManager getManaManager() { return this.manaManager; }
    public CloneManager getCloneManager() { return this.cloneManager; }
    public int getGlobalTickCounter() { return this.globalTickCounter; }

    public static StorageConfig getConfig() {
        if (savedConfig == null) savedConfig = StorageConfig.load();
        return savedConfig;
    }

    public static SlotSettings getSlotSettings(int slot) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || slot < 0 || slot > 8) return null;
        return getSettingsForItem(client.field_1724.method_31548().method_5438(slot));
    }

    public static SlotSettings getSettingsForItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;
        StorageConfig config = getConfig();
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        int customModelData = 0;
        if (stack.method_7985() && stack.method_7969().method_10545("CustomModelData")) {
            customModelData = stack.method_7969().method_10550("CustomModelData");
        }
        String currentItemName = stack.method_7964().getString();
        String globalKey = itemId + ":" + customModelData;

        if (config.normalItems != null) {
            for (StorageConfig.ItemPreset preset : config.normalItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    return new SlotSettings(globalKey, currentItemName, preset.leftCD, preset.rightCD, preset.leftMana, preset.rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        if (config.leveledItems != null) {
            for (StorageConfig.LeveledItemPreset preset : config.leveledItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    int leftCd = preset.leftCD, rightCd = preset.rightCD, leftMana = preset.leftMana, rightMana = preset.rightMana;
                    if (preset.levels != null && currentItemName != null) {
                        for (StorageConfig.ItemLevel lvl : preset.levels) {
                            if (currentItemName.contains(lvl.levelNameIndicator)) {
                                leftCd = lvl.leftCD; rightCd = lvl.rightCD;
                                leftMana = lvl.leftMana; rightMana = lvl.rightMana;
                                break;
                            }
                        }
                    }
                    return new SlotSettings(globalKey, currentItemName, leftCd, rightCd, leftMana, rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        return null;
    }

    public record SlotSettings(String cooldownKey, String displayName, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {}
}