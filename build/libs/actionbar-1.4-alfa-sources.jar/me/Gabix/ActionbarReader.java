package me.Gabix;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_337;

public class ActionbarReader {
    private static String lastRawActionbarText = "";
    private static String lastCleanActionbarText = "";
    private static long lastActionbarUpdateTime = 0;

    private static boolean continuousTitle = true;
    private static boolean titleShownForCurrentBoss = false;

    public static int currentDamage = 0;
    public static boolean isDamageReady = false;

    private static long lastDamageUpdateTime = 0;
    private static boolean wasDamageReady = false;

    private static final Pattern MANA_PATTERN = Pattern.compile("§b(\\d+)§8/§b\\d+");
    private static final Pattern DAMAGE_PATTERN = Pattern.compile("Sebzés:\\s*.*?§f(\\d+)");

    private static Field cachedBossBarsField = null;

    public static void init() {}

    public static void handleTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (System.currentTimeMillis() - lastActionbarUpdateTime > 3000) {
            lastRawActionbarText = "";
            lastCleanActionbarText = "";
        }

        try {
            if (client.field_1705 != null) {
                class_337 bossBarHud = client.field_1705.method_1740();
                if (cachedBossBarsField == null) {
                    for (Field field : class_337.class.getDeclaredFields()) {
                        if (Map.class.isAssignableFrom(field.getType())) {
                            field.setAccessible(true);
                            cachedBossBarsField = field;
                            break;
                        }
                    }
                }

                if (cachedBossBarsField != null) {
                    Map<?, ?> bossBars = (Map<?, ?>) cachedBossBarsField.get(bossBarHud);
                    if (bossBars == null || bossBars.isEmpty()) {
                        titleShownForCurrentBoss = false;
                    } else {
                        for (Object value : bossBars.values()) {
                            if (value instanceof class_1259 bossBar) {
                                String cleanBossName = bossBar.method_5414().getString().toLowerCase();
                                StorageConfig config = ActionbarStorageClient.getConfig();
                                if (config != null && config.autoBossDetection) {
                                    String targetBoss = null;
                                    if (cleanBossName.contains("ender") && cleanBossName.contains("mágus")) targetBoss = "Endermágus";
                                    else if (cleanBossName.contains("trex") || cleanBossName.contains("t-rex") || cleanBossName.contains("㕕ꈂ㕖ꈂ㕗ꈂ㕘ꈂ㕙ꈂ㕚ꈂ㕛ꈂ㕜")) targetBoss = "Trex";
                                    else if (cleanBossName.contains("warden")) targetBoss = "Warden";
                                    else if (cleanBossName.contains("radio") && (cleanBossName.contains("pók") || cleanBossName.contains("pok"))) targetBoss = "RadioPók";
                                    else if (((cleanBossName.contains("jég") || cleanBossName.contains("jeg")) && (cleanBossName.contains("sárkány") || cleanBossName.contains("sarkany")))
                                            || cleanBossName.contains("ice dragon")
                                            || cleanBossName.contains("icedragon")
                                            || cleanBossName.contains("㔎ꈂ㔏ꈂ㔐ꈂ㔑ꈂ㔒ꈂ㔓ꈂ㔔ꈂ㔖膛ꈋꈃꈇ㪀ꈂ㪁ꈂ㪂ꈂ㪃ꈂ㪄ꈂ㪅ꈂ㪆")) {
                                        targetBoss = "JégSárkány";
                                    }
                                    else if (cleanBossName.contains("kraken")) targetBoss = "Kraken";

                                    if (targetBoss != null && !config.selectedBossNotification.equals(targetBoss)) {
                                        config.selectedBossNotification = targetBoss;
                                        titleShownForCurrentBoss = false;
                                        currentDamage = 0;
                                        wasDamageReady = false;
                                        client.field_1705.method_34001(5, 20, 5);
                                        client.field_1705.method_34004(class_2561.method_43470("§d§lMÓD VÁLTVA"));
                                        client.field_1705.method_34002(class_2561.method_43470("§eProfil automatikusan átállítva: §b" + targetBoss));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {}

        if (currentDamage > 0 && System.currentTimeMillis() - lastDamageUpdateTime > 30000) {
            currentDamage = 0;
            if (ActionbarStorageClient.getInstance() != null && ActionbarStorageClient.getInstance().getManaManager() != null) {
                ActionbarStorageClient.getInstance().getManaManager().setCurrentDamage(0);
            }
        }

        int targetDamage = 5000;
        StorageConfig config = ActionbarStorageClient.getConfig();
        if (config != null) {
            targetDamage = config.getTargetBossDamage();
        }

        boolean isNowReady = (currentDamage >= targetDamage && currentDamage > 0);
        isDamageReady = isNowReady;

        if (isNowReady && !wasDamageReady) {
            if (client.field_1705 != null) {
                if (continuousTitle) {
                    client.field_1705.method_34001(5, 72000, 5);
                } else {
                    client.field_1705.method_34001(5, 20, 5);
                }
                client.field_1705.method_34004(class_2561.method_43470("§a§l★ KÉSZ ★"));
            }
        } else if (!isNowReady && wasDamageReady) {
            if (client.field_1705 != null) {
                client.field_1705.method_34001(0, 0, 0);
                client.field_1705.method_34004(class_2561.method_43473());
            }
        }
        wasDamageReady = isNowReady;

        while (ActionbarStorageClient.toggleContinuousKeyBinding.method_1436()) {
            continuousTitle = !continuousTitle;
            if (isNowReady) {
                if (client.field_1705 != null) {
                    if (continuousTitle) {
                        client.field_1705.method_34001(0, 72000, 5);
                    } else {
                        client.field_1705.method_34001(0, 20, 5);
                    }
                    client.field_1705.method_34004(class_2561.method_43470("§a§l★ KÉSZ ★"));
                }
            } else {
                wasDamageReady = false;
                if (client.field_1705 != null) {
                    client.field_1705.method_34001(0, 0, 0);
                    client.field_1705.method_34004(class_2561.method_43473());
                    client.field_1705.method_34002(class_2561.method_43473());
                }
            }
            if (continuousTitle) {
                client.field_1724.method_7353(class_2561.method_43470("§a[Mod] Kész felirat: §eFolyamatosan a képernyőn marad"), false);
            } else {
                client.field_1724.method_7353(class_2561.method_43470("§a[Mod] Kész felirat: §eCsak egyszer villan fel"), false);
            }
        }

        while (ActionbarStorageClient.readActionbarKeyBinding.method_1436()) {
            if (lastRawActionbarText == null || lastRawActionbarText.isEmpty()) {
                client.field_1724.method_7353(class_2561.method_43470("§c[Actionbar] Jelenleg nincs aktív Actionbar a képernyőn!"), false);
            } else {
                String formattedWithAmpersand = lastRawActionbarText.replace("§", "&");
                client.field_1724.method_7353(class_2561.method_43470("§a[Actionbar] Aktív Actionbar adatok:"), false);
                client.field_1724.method_7353(class_2561.method_43470("§e - Tiszta név: §f" + lastCleanActionbarText), false);
                client.field_1724.method_7353(class_2561.method_43470("§e   Színezett/Kódolt (&): §f" + formattedWithAmpersand), false);
            }
        }

        while (ActionbarStorageClient.readBossBarsKeyBinding.method_1436()) {
            readBossBars(client);
        }
    }

    public static void readBossBars(class_310 client) {
        if (client.field_1724 == null || client.field_1705 == null) return;
        try {
            class_337 bossBarHud = client.field_1705.method_1740();
            if (cachedBossBarsField == null) {
                for (Field field : class_337.class.getDeclaredFields()) {
                    if (Map.class.isAssignableFrom(field.getType())) {
                        field.setAccessible(true);
                        cachedBossBarsField = field;
                        break;
                    }
                }
            }
            if (cachedBossBarsField != null) {
                Map<?, ?> bossBars = (Map<?, ?>) cachedBossBarsField.get(bossBarHud);
                if (bossBars == null || bossBars.isEmpty()) {
                    client.field_1724.method_7353(class_2561.method_43470("§c[BossBar] Jelenleg nincs aktív BossBar a képernyőn!"), false);
                } else {
                    client.field_1724.method_7353(class_2561.method_43470("§a[BossBar] Képernyőn lévő BossBar-ok:"), false);
                    for (Object value : bossBars.values()) {
                        if (value instanceof class_1259 bossBar) {
                            String rawName = bossBar.method_5414().getString();
                            String formattedTextWithAmpersand = toRawLegacyText(bossBar.method_5414());
                            client.field_1724.method_7353(class_2561.method_43470("§e - Tiszta név: §f" + rawName), false);
                            client.field_1724.method_7353(class_2561.method_43470("§e   Színezett/Kódolt (&): §f" + formattedTextWithAmpersand), false);
                        }
                    }
                }
            }
        } catch (Exception e) {
            client.field_1724.method_7353(class_2561.method_43470("§c[BossBar] Hiba történt a BossBar-ok kiolvasása közben!"), false);
        }
    }

    public static void updateText(class_2561 text) {
        if (text == null) return;
        lastActionbarUpdateTime = System.currentTimeMillis();
        lastCleanActionbarText = text.getString();
        String rawText = toRawLegacyText(text).replace("&", "§");
        lastRawActionbarText = rawText;

        Matcher manaMatcher = MANA_PATTERN.matcher(rawText);
        if (manaMatcher.find()) {
            try {
                int foundMana = Integer.parseInt(manaMatcher.group(1));
                if (ActionbarStorageClient.getInstance() != null && ActionbarStorageClient.getInstance().getManaManager() != null) {
                    ActionbarStorageClient.getInstance().getManaManager().setCurrentMana(foundMana);
                }
            } catch (NumberFormatException ignored) {}
        }

        Matcher dmgMatcher = DAMAGE_PATTERN.matcher(rawText);
        if (dmgMatcher.find()) {
            try {
                int foundDamage = Integer.parseInt(dmgMatcher.group(1));
                currentDamage = foundDamage;
                lastDamageUpdateTime = System.currentTimeMillis();
                if (ActionbarStorageClient.getInstance() != null && ActionbarStorageClient.getInstance().getManaManager() != null) {
                    ActionbarStorageClient.getInstance().getManaManager().setCurrentDamage(foundDamage);
                }
            } catch (NumberFormatException ignored) {}
        }
    }

    private static String toRawLegacyText(class_2561 text) {
        if (text == null) return "";
        StringBuilder raw = new StringBuilder();
        text.method_27658((style, string) -> {
            if (style != null) {
                if (style.method_10973() != null) {
                    switch (style.method_10973().method_27721()) {
                        case "black" -> raw.append("&0");
                        case "dark_blue" -> raw.append("&1");
                        case "dark_green" -> raw.append("&2");
                        case "dark_aqua" -> raw.append("&3");
                        case "dark_red" -> raw.append("&4");
                        case "dark_purple" -> raw.append("&5");
                        case "gold" -> raw.append("&6");
                        case "gray" -> raw.append("&7");
                        case "dark_gray" -> raw.append("&8");
                        case "blue" -> raw.append("&9");
                        case "green" -> raw.append("&a");
                        case "aqua" -> raw.append("&b");
                        case "red" -> raw.append("&c");
                        case "light_purple" -> raw.append("&d");
                        case "yellow" -> raw.append("&e");
                        case "white" -> raw.append("&f");
                    }
                }
                if (style.method_10987()) raw.append("&k");
                if (style.method_10984()) raw.append("&l");
                if (style.method_10986()) raw.append("&m");
                if (style.method_10965()) raw.append("&n");
                if (style.method_10966()) raw.append("&o");
            }
            raw.append(string);
            return Optional.empty();
        }, net.minecraft.class_2583.field_24360);
        return raw.toString();
    }

    public static String getLastRawActionbarText() { return lastRawActionbarText; }
    public static String getLastCleanActionbarText() { return lastCleanActionbarText; }
}