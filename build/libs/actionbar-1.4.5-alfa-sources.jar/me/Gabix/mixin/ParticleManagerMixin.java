package me.Gabix.mixin;

import me.Gabix.ActionbarStorageClient;
import me.Gabix.StorageConfig;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_702.class)
public class ParticleManagerMixin {

    @Inject(method = "addBlockBreakParticles", at = @At("HEAD"), cancellable = true)
    private void onAddBlockBreakParticles(class_2338 pos, class_2680 state, CallbackInfo ci) {
        StorageConfig config = ActionbarStorageClient.getConfig();
        if (config != null && config.hideBlockBreakingParticles) {
            ci.cancel();
        }
    }

    @Inject(method = "addBlockBreakingParticles", at = @At("HEAD"), cancellable = true)
    private void onAddBlockBreakingParticles(class_2338 pos, class_2350 direction, CallbackInfo ci) {
        StorageConfig config = ActionbarStorageClient.getConfig();
        if (config != null && config.hideBlockBreakingParticles) {
            ci.cancel();
        }
    }
}