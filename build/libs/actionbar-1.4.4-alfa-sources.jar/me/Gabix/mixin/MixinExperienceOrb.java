package me.Gabix.mixin;

import me.Gabix.clumps.ClumpsCommon;
import me.Gabix.clumps.api.events.IRepairEvent;
import me.Gabix.clumps.api.events.IValueEvent;
import me.Gabix.clumps.helper.IClumpedOrb;
import me.Gabix.clumps.platform.FabricEventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Mixin(value = class_1303.class, priority = 1001)
public abstract class MixinExperienceOrb extends class_1297 implements IClumpedOrb {
    @Shadow private int amount;
    @Shadow private int pickingCount;
    @Shadow private int health;

    @Unique public Map<Integer, Integer> clumps$clumpedMap;

    @Shadow protected abstract int repairPlayerGears(class_1657 player, int amount);

    public MixinExperienceOrb(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Inject(method = "isMergeable(Lnet/minecraft/entity/ExperienceOrbEntity;)Z", at = @At("HEAD"), cancellable = true)
    private void canMerge(class_1303 experienceOrb, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(experienceOrb.method_5805() && !this.equals(experienceOrb));
    }

    @Inject(method = "isMergeable(Lnet/minecraft/entity/ExperienceOrbEntity;II)Z", at = @At("HEAD"), cancellable = true)
    private static void canMerge(class_1303 experienceOrb, int i, int j, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(experienceOrb.method_5805());
    }

    @Inject(method = "onPlayerCollision(Lnet/minecraft/entity/player/PlayerEntity;)V", at = @At("HEAD"), cancellable = true)
    public void onPlayerCollision(class_1657 player, CallbackInfo ci) {
        if (!this.field_6002.field_9236) {
            if (ClumpsCommon.pickupXPEvent.test(player, (class_1303) (Object) this)) {
                return;
            }

            player.field_7504 = 0;
            player.method_6103(this, 1);
            if (this.pickingCount != 0 || this.clumps$resolve()) {
                AtomicInteger toGive = new AtomicInteger();
                this.clumps$getClumpedMap().forEach((value, amount) -> {
                    IValueEvent valueEvent = FabricEventHandler.fireValueEvent(player, value);
                    int actualValue = valueEvent.getValue();

                    for (int i = 0; i < amount; i++) {
                        IRepairEvent repairEvent = FabricEventHandler.fireRepairEvent(player, actualValue);
                        int leftOver = repairEvent.getValue();
                        if (leftOver == actualValue) {
                            leftOver = this.repairPlayerGears(player, actualValue);
                        }
                        if (leftOver > 0) {
                            toGive.addAndGet(leftOver);
                        }
                    }
                });
                if (toGive.get() > 0) {
                    player.method_7255(toGive.get());
                }
            }
            this.method_31472();
            ci.cancel();
        }
    }

    @Inject(
            method = "merge(Lnet/minecraft/entity/ExperienceOrbEntity;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/ExperienceOrbEntity;discard()V",
                    shift = At.Shift.BEFORE
            ),
            cancellable = true
    )
    public void merge(class_1303 secondaryOrb, CallbackInfo ci) {
        Map<Integer, Integer> otherMap = ((IClumpedOrb) secondaryOrb).clumps$getClumpedMap();
        this.amount = this.clumps$getClumpedMap().values().stream().reduce(Integer::sum).orElse(1);
        this.health = Math.min(this.health, ((ExperienceOrbAccess) secondaryOrb).clumps$getHealth());
        this.clumps$setClumpedMap(Stream.of(this.clumps$getClumpedMap(), otherMap)
                .flatMap(map -> map.entrySet().stream())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, Integer::sum)));
        secondaryOrb.method_31472();
        ci.cancel();
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    public void writeCustomDataToNbt(class_2487 compoundTag, CallbackInfo ci) {
        class_2487 map = new class_2487();
        this.clumps$getClumpedMap().forEach((value, count) -> map.method_10569("" + value, count));
        compoundTag.method_10566("clumpedMap", map);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    public void readCustomDataFromNbt(class_2487 compoundTag, CallbackInfo ci) {
        Map<Integer, Integer> map = new HashMap<>();
        if (compoundTag.method_10545("clumpedMap")) {
            class_2487 clumpedMap = compoundTag.method_10562("clumpedMap");
            for (String s : clumpedMap.method_10541()) {
                map.put(Integer.parseInt(s), clumpedMap.method_10550(s));
            }
        } else {
            map.put(this.pickingCount, this.amount);
        }
        this.clumps$setClumpedMap(map);
    }

    @Override
    public Map<Integer, Integer> clumps$getClumpedMap() {
        if (this.clumps$clumpedMap == null) {
            this.clumps$clumpedMap = new HashMap<>();
            this.clumps$clumpedMap.put(this.pickingCount, 1);
        }
        return this.clumps$clumpedMap;
    }

    @Override
    public void clumps$setClumpedMap(Map<Integer, Integer> map) {
        this.clumps$clumpedMap = map;
        this.clumps$resolve();
    }

    @Override
    public boolean clumps$resolve() {
        this.pickingCount = this.clumps$getClumpedMap().entrySet().stream()
                .map(entry -> entry.getKey() * entry.getValue())
                .reduce(Integer::sum).orElse(1);
        return this.pickingCount > 0;
    }
}