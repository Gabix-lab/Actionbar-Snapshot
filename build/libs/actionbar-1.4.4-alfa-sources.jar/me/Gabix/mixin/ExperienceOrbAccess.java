package me.Gabix.mixin;

import net.minecraft.class_1303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1303.class)
public interface ExperienceOrbAccess {
    @Accessor("health")
    int clumps$getHealth();

    @Accessor("health")
    void clumps$setHealth(int health);

    @Accessor("amount")
    void clumps$setAmount(int amount);
}