package me.Gabix.mixin;

import me.Gabix.ActionbarReader;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class ActionbarMixin {

    @Inject(method = "setOverlayMessage", at = @At("HEAD"))
    private void onActionbarUpdate(class_2561 message, boolean tinted, CallbackInfo ci) {
        ActionbarReader.updateText(message);
    }
}