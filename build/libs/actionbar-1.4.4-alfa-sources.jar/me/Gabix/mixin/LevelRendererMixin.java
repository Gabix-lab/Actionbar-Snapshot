package me.Gabix.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import me.Gabix.NoRenderManager;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_3568;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_702;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_761.class)
public class LevelRendererMixin {

    @WrapWithCondition(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/chunk/light/LightingProvider;doLightUpdates()I"), require = 0)
    private boolean skipLightUpdates(class_3568 instance) { return !NoRenderManager.enabled; }

    @ModifyExpressionValue(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/world/ClientWorld;getEntities()Ljava/lang/Iterable;"), require = 0)
    private Iterable<class_1297> hideEntities(Iterable<class_1297> original) { return NoRenderManager.enabled ? Collections.emptyList() : original; }

    @WrapWithCondition(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;renderLayer(Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/util/math/MatrixStack;DDDLorg/joml/Matrix4f;)V"), require = 0)
    private boolean hideBlocks(class_761 instance, class_1921 renderLayer, class_4587 matrices, double cameraX, double cameraY, double cameraZ, Matrix4f positionMatrix) { return !NoRenderManager.enabled; }

    @ModifyExpressionValue(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/chunk/ChunkBuilder$BuiltChunk$RebuildTask$RenderData;getBlockEntities()Ljava/util/List;"), require = 0)
    private List<class_2586> hideBlockEntities(List<class_2586> original) { return NoRenderManager.enabled ? Collections.emptyList() : original; }

    @ModifyExpressionValue(method = "render", at = @At(value = "FIELD", target = "Lnet/minecraft/client/render/WorldRenderer;noCullingBlockEntities:Ljava/util/Set;", ordinal = 0), require = 0)
    private Set<class_2586> hideGlobalBlockEntities(Set<class_2586> original) { return NoRenderManager.enabled ? Collections.emptySet() : original; }

    @WrapWithCondition(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V"), require = 0)
    private boolean hideSky(class_761 instance, class_4587 matrices, Matrix4f projectionMatrix, float tickDelta, class_4184 camera, boolean thickFog, Runnable fogCallback) { return !NoRenderManager.enabled; }

    @WrapWithCondition(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;renderClouds(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FDDD)V"), require = 0)
    private boolean hideClouds(class_761 instance, class_4587 matrices, Matrix4f projectionMatrix, float tickDelta, double cameraX, double cameraY, double cameraZ) { return !NoRenderManager.enabled; }

    @WrapWithCondition(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/particle/ParticleManager;renderParticles(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/render/LightmapTextureManager;Lnet/minecraft/client/render/Camera;F)V"), require = 0)
    private boolean hideParticles(class_702 instance, class_4587 matrixStack, class_4597.class_4598 immediate, class_765 lightmapTextureManager, class_4184 camera, float f) { return !NoRenderManager.enabled; }
}