package me.Gabix.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import me.Gabix.NoRenderManager;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_758.class)
public class FogMixin {

    @Inject(method = "applyFog", at = @At("HEAD"), cancellable = true)
    private static void hideFog(class_4184 camera, class_758.class_4596 fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        if (NoRenderManager.enabled && fogType == class_758.class_4596.field_20946) {
            RenderSystem.setShaderFogStart(200000.0F);
            RenderSystem.setShaderFogEnd(200000.0F);
            ci.cancel();
        }
    }
}