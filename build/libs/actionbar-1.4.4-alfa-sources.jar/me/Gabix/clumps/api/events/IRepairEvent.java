package me.Gabix.clumps.api.events;

import net.minecraft.class_1657;

public interface IRepairEvent {
    void setValue(int value);
    int getValue();
    class_1657 getPlayer();
}