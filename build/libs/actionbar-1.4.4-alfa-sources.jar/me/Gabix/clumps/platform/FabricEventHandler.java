package me.Gabix.clumps.platform;

import me.Gabix.clumps.api.events.IValueEvent;
import me.Gabix.clumps.api.events.IRepairEvent;
import me.Gabix.clumps.api.events.ValueEvent;
import net.minecraft.class_1657;
import me.Gabix.clumps.api.events.RepairEvent;

public class FabricEventHandler {
    public static IValueEvent fireValueEvent(class_1657 player, int value) {
        return new ValueEvent(player, value);
    }

    public static IRepairEvent fireRepairEvent(class_1657 player, int value) {
        return new RepairEvent(player, value);
    }
}