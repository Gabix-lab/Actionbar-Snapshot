package me.Gabix;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public class FullbrightManager {
    public static boolean enabled = true;

    public static void toggle(class_310 client) {
        enabled = !enabled;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("§7[GabixMod] §fFullbright: " +
                    (enabled ? "§aBE" : "§cKI")), true);
        }
    }
}