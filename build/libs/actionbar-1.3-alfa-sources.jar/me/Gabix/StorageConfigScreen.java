package me.Gabix;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class StorageConfigScreen extends class_437 {
    private final StorageConfig config;
    private ItemPresetListWidget listWidget;

    public StorageConfigScreen(StorageConfig config) {
        super(class_2561.method_43470("Actionbar Storage Beállítások"));
        this.config = config;
    }

    @Override
    protected void method_25426() {
        this.listWidget = new ItemPresetListWidget(this.config);
        this.method_25429(this.listWidget);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Bezárás"), button -> {
            this.config.save();
            this.method_25419();
        }).method_46434(this.field_22789 / 2 - 100, this.field_22790 - 26, 200, 20).method_46431());
    }

    // FŐ KATTINTÁS KEZELÉS A KÉPERNYŐN
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && this.field_22787 != null && this.field_22787.field_1724 != null) {
            long windowHandle = this.field_22787.method_22683().method_4490();

            // Ellenőrizzük, hogy a jobb oldali Shift le van-e nyomva
            if (class_3675.method_15987(windowHandle, GLFW.GLFW_KEY_RIGHT_SHIFT)) {

                // Megnézzük, hogy az egér a görgethető lista határain belül van-e
                if (mouseY >= this.listWidget.getTop() && mouseY <= this.listWidget.getBottom() && mouseX >= this.listWidget.getLeft() && mouseX <= this.listWidget.getRight()) {

                    // A nyilvános segédmetóduson keresztül kérjük le az elemet
                    ItemPresetListWidget.Entry hoveredEntry = this.listWidget.getHoveredEntry(mouseX, mouseY);
                    if (hoveredEntry != null) {

                        // 1. Sima tárgy sorra való kattintáskor
                        if (hoveredEntry instanceof ItemPresetListWidget.NormalItemEntry) {
                            StorageConfig.ItemPreset preset = ((ItemPresetListWidget.NormalItemEntry) hoveredEntry).preset;
                            String cmd = "give @s " + preset.itemId + "{CustomModelData:" + preset.customModelData + ",display:{Name:'{\"text\":\"" + preset.name.replace("§", "\\u00A7") + "\",\"italic\":false}'}}";
                            this.field_22787.field_1724.field_3944.method_45731(cmd);
                            return true;
                        }

                        // 2. Fejleszthető al-szintre való kattintáskor
                        if (hoveredEntry instanceof ItemPresetListWidget.LevelSubEntry) {
                            StorageConfig.ItemLevel level = ((ItemPresetListWidget.LevelSubEntry) hoveredEntry).level;
                            StorageConfig.LeveledItemPreset parentPreset = null;
                            if (this.config.leveledItems != null) {
                                for (StorageConfig.LeveledItemPreset p : this.config.leveledItems) {
                                    if (p.levels != null && p.levels.contains(level)) {
                                        parentPreset = p;
                                        break;
                                    }
                                }
                            }
                            if (parentPreset != null) {
                                String fullName = parentPreset.name + " " + level.levelNameIndicator;
                                String cmd = "give @s " + parentPreset.itemId + "{CustomModelData:" + parentPreset.customModelData + ",display:{Name:'{\"text\":\"" + fullName.replace("§", "\\u00A7") + "\",\"italic\":false}'}}";
                                this.field_22787.field_1724.field_3944.method_45731(cmd);
                                return true;
                            }
                        }

                        // 3. Fő lenyíló fejléc sorra való kattintáskor
                        if (hoveredEntry instanceof ItemPresetListWidget.LeveledItemHeaderEntry) {
                            StorageConfig.LeveledItemPreset preset = ((ItemPresetListWidget.LeveledItemHeaderEntry) hoveredEntry).preset;
                            String cmd = "give @s " + preset.itemId + "{CustomModelData:" + preset.customModelData + ",display:{Name:'{\"text\":\"" + preset.name.replace("§", "\\u00A7") + "\",\"italic\":false}'}}";
                            this.field_22787.field_1724.field_3944.method_45731(cmd);
                            return true;
                        }
                    }
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);
        this.listWidget.method_25394(matrices, mouseX, mouseY, delta);
        method_27534(matrices, this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFF);
        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    private class ItemPresetListWidget extends class_4265<ItemPresetListWidget.Entry> {
        public ItemPresetListWidget(StorageConfig config) {
            super(StorageConfigScreen.this.field_22787, StorageConfigScreen.this.field_22789, StorageConfigScreen.this.field_22790, 24, StorageConfigScreen.this.field_22790 - 32, 24);

            this.method_25321(new BossNotificationEntry(config));
            this.method_25321(new HudSlotsToggleEntry(config));

            if (config.normalItems != null) {
                for (StorageConfig.ItemPreset preset : config.normalItems) {
                    this.method_25321(new NormalItemEntry(preset));
                }
            }

            if (config.leveledItems != null) {
                for (StorageConfig.LeveledItemPreset leveledPreset : config.leveledItems) {
                    LeveledItemHeaderEntry header = new LeveledItemHeaderEntry(leveledPreset, this);
                    this.method_25321(header);
                }
            }
        }

        // Ez a híd-metódus feloldja a protected hozzáférési hibát
        public Entry getHoveredEntry(double mouseX, double mouseY) {
            return this.method_25308(mouseX, mouseY);
        }

        public int getLeft() { return this.field_19088; }
        public int getRight() { return this.field_19087; }
        public int getTop() { return this.field_19085; }
        public int getBottom() { return this.field_19086; }

        public void toggleLevels(LeveledItemHeaderEntry header, StorageConfig.LeveledItemPreset preset) {
            int headerIndex = this.method_25396().indexOf(header);
            if (headerIndex == -1) return;

            if (header.isExpanded()) {
                int insertOffset = 1;
                for (StorageConfig.ItemLevel level : preset.levels) {
                    this.method_25396().add(headerIndex + insertOffset, new LevelSubEntry(level));
                    insertOffset++;
                }
            } else {
                int numLevels = preset.levels.size();
                for (int i = 0; i < numLevels; i++) {
                    if (headerIndex + 1 < this.method_25396().size() && this.method_25396().get(headerIndex + 1) instanceof LevelSubEntry) {
                        this.method_25396().remove(headerIndex + 1);
                    }
                }
            }
        }

        @Override
        public int method_25322() { return 360; }

        @Override
        protected int method_25329() { return this.field_22742 / 2 + 190; }

        abstract static class Entry extends class_4265.class_4266<Entry> {}

        private class BossNotificationEntry extends Entry {
            private final StorageConfig config;
            private final class_4185 cycleButton;
            private final List<net.minecraft.class_364> children = new ArrayList<>();
            private final List<class_4185> selectables = new ArrayList<>();
            private final String[] choices = {"Ki", "JégSárkány", "Trex", "Endermágus", "Warden", "RadioPók", "Kraken"};

            public BossNotificationEntry(StorageConfig config) {
                this.config = config;

                this.cycleButton = class_4185.method_46430(class_2561.method_43470(config.selectedBossNotification), button -> {
                    int currentIndex = 0;
                    for (int i = 0; i < choices.length; i++) {
                        if (choices[i].equals(config.selectedBossNotification)) {
                            currentIndex = i;
                            break;
                        }
                    }
                    int nextIndex = (currentIndex + 1) % choices.length;
                    config.selectedBossNotification = choices[nextIndex];
                    button.method_25355(class_2561.method_43470(config.selectedBossNotification));
                }).method_46434(0, 0, 100, 18).method_46431();

                this.children.add(this.cycleButton);
                this.selectables.add(this.cycleButton);
            }

            @Override
            public void method_25343(class_4587 matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                method_25294(matrices, x, y, x + entryWidth, y + entryHeight - 2, 0x4400AAAA);
                StorageConfigScreen.this.field_22793.method_1720(matrices, "§bBoss Sebzés Értesítő:", x + 6, y + 5, 0xFFFFFF);

                this.cycleButton.method_46421(x + entryWidth - 106);
                this.cycleButton.method_46419(y + 1);
                this.cycleButton.method_25394(matrices, mouseX, mouseY, delta);
            }

            @Override
            public List<? extends net.minecraft.class_364> method_25396() { return this.children; }
            @Override
            public List<? extends net.minecraft.class_6379> method_37025() { return this.selectables; }
        }

        private class HudSlotsToggleEntry extends Entry {
            private final List<class_4185> buttons = new ArrayList<>();
            private final List<net.minecraft.class_364> children = new ArrayList<>();

            public HudSlotsToggleEntry(StorageConfig config) {
                for (int i = 0; i < 9; i++) {
                    final int slotIndex = i;
                    boolean isEnabled = config.hudSlotsEnabled[slotIndex];
                    class_4185 btn = class_4185.method_46430(class_2561.method_43470(String.valueOf(slotIndex + 1)), button -> {
                        config.hudSlotsEnabled[slotIndex] = !config.hudSlotsEnabled[slotIndex];
                        updateButtonColor(button, config.hudSlotsEnabled[slotIndex]);
                    }).method_46434(0, 0, 16, 18).method_46431();

                    updateButtonColor(btn, isEnabled);
                    buttons.add(btn);
                    children.add(btn);
                }
            }

            private void updateButtonColor(class_4185 button, boolean enabled) {
                String num = button.method_25369().getString().replaceAll("§.", "");
                if (enabled) {
                    button.method_25355(class_2561.method_43470("§a" + num));
                } else {
                    button.method_25355(class_2561.method_43470("§c" + num));
                }
            }

            @Override
            public void method_25343(class_4587 matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                method_25294(matrices, x, y, x + entryWidth, y + entryHeight - 2, 0x4422AAAA);
                StorageConfigScreen.this.field_22793.method_1720(matrices, "§eHUD Slotok:", x + 6, y + 5, 0xFFFFFF);

                int startX = x + entryWidth - 165;
                for (int i = 0; i < buttons.size(); i++) {
                    class_4185 btn = buttons.get(i);
                    btn.method_46421(startX + (i * 18));
                    btn.method_46419(y + 1);
                    btn.method_25394(matrices, mouseX, mouseY, delta);
                }
            }

            @Override
            public List<? extends net.minecraft.class_364> method_25396() { return this.children; }
            @Override
            public List<? extends net.minecraft.class_6379> method_37025() { return this.buttons; }
        }

        public class NormalItemEntry extends Entry {
            public final StorageConfig.ItemPreset preset;
            private final List<net.minecraft.class_364> children = new ArrayList<>();

            public NormalItemEntry(StorageConfig.ItemPreset preset) { this.preset = preset; }

            @Override
            public void method_25343(class_4587 matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                int bgColor = hovered ? 0x44FFFFFF : 0x22FFFFFF;
                method_25294(matrices, x, y, x + entryWidth, y + entryHeight - 2, bgColor);

                String label = preset.name + " §7(CMD: " + preset.customModelData + ")";
                StorageConfigScreen.this.field_22793.method_1720(matrices, label, x + 6, y + 6, 0xE0E0E0);
                String info = "§7B: §e" + (preset.leftCD / 20.0f) + "s §7| J: §d" + (preset.rightCD / 20.0f) + "s";
                int infoWidth = StorageConfigScreen.this.field_22793.method_1727(info);
                StorageConfigScreen.this.field_22793.method_1720(matrices, info, x + entryWidth - infoWidth - 6, y + 6, 0xFFFFFF);
            }

            @Override
            public List<? extends net.minecraft.class_364> method_25396() { return this.children; }
            @Override
            public List<? extends net.minecraft.class_6379> method_37025() { return java.util.Collections.emptyList(); }
        }

        public class LeveledItemHeaderEntry extends Entry {
            public final StorageConfig.LeveledItemPreset preset;
            private final class_4185 toggleButton;
            private final List<net.minecraft.class_364> children = new ArrayList<>();
            private final List<class_4185> selectables = new ArrayList<>();
            private boolean expanded = false;

            public LeveledItemHeaderEntry(StorageConfig.LeveledItemPreset preset, ItemPresetListWidget parent) {
                this.preset = preset;
                this.toggleButton = class_4185.method_46430(class_2561.method_43470("▶"), button -> {
                    this.expanded = !this.expanded;
                    button.method_25355(class_2561.method_43470(this.expanded ? "▼" : "▶"));
                    parent.toggleLevels(this, this.preset);
                }).method_46434(0, 0, 20, 18).method_46431();
                this.children.add(this.toggleButton);
                this.selectables.add(this.toggleButton);
            }

            public boolean isExpanded() { return expanded; }

            @Override
            public void method_25343(class_4587 matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                method_25294(matrices, x, y, x + entryWidth, y + entryHeight - 2, 0x44AA00AA);
                this.toggleButton.method_46421(x + 4);
                this.toggleButton.method_46419(y + 1);
                this.toggleButton.method_25394(matrices, mouseX, mouseY, delta);
                String label = "§6" + preset.name + " §7(CMD: " + preset.customModelData + ") §d[Fejleszthető]";
                StorageConfigScreen.this.field_22793.method_1720(matrices, label, x + 28, y + 5, 0xFFFFFF);
            }

            @Override
            public List<? extends net.minecraft.class_364> method_25396() { return this.children; }
            @Override
            public List<? extends net.minecraft.class_6379> method_37025() { return this.selectables; }
        }

        public class LevelSubEntry extends Entry {
            public final StorageConfig.ItemLevel level;
            private final List<net.minecraft.class_364> children = new ArrayList<>();

            public LevelSubEntry(StorageConfig.ItemLevel level) { this.level = level; }

            @Override
            public void method_25343(class_4587 matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                int bgColor = hovered ? 0x44000000 : 0x22000000;
                method_25294(matrices, x + 15, y, x + entryWidth, y + entryHeight - 2, bgColor);
                method_25294(matrices, x + 8, y, x + 9, y + entryHeight, 0x44FFFFFF);
                method_25294(matrices, x + 8, y + (entryHeight / 2), x + 14, y + (entryHeight / 2) + 1, 0x44FFFFFF);
                String lvlLabel = "§b• " + level.levelNameIndicator;
                StorageConfigScreen.this.field_22793.method_1720(matrices, lvlLabel, x + 20, y + 6, 0xE0E0E0);
                String stats = "§7B: §e" + (level.leftCD / 20.0f) + "s (" + level.leftMana + "m) §7| J: §d" + (level.rightCD / 20.0f) + "s (" + level.rightMana + "m)";
                int statsWidth = StorageConfigScreen.this.field_22793.method_1727(stats);
                StorageConfigScreen.this.field_22793.method_1720(matrices, stats, x + entryWidth - statsWidth - 6, y + 6, 0xCCCCCC);
            }

            @Override
            public List<? extends net.minecraft.class_364> method_25396() { return this.children; }
            @Override
            public List<? extends net.minecraft.class_6379> method_37025() { return java.util.Collections.emptyList(); }
        }
    }
}