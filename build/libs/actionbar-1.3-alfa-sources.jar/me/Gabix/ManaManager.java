package me.Gabix;

public class ManaManager {
    private int currentMana = 100;
    private int currentDamage = 0;

    public int getCurrentMana() {
        return this.currentMana;
    }

    public void setCurrentMana(int mana) {
        this.currentMana = mana;
    }

    public int getCurrentDamage() {
        return this.currentDamage;
    }

    public void setCurrentDamage(int damage) {
        this.currentDamage = damage;
    }
}