package me.Gabix.mixin;

import me.Gabix.ActionbarStorageClient;
import me.Gabix.ActionbarReader;
import me.Gabix.StorageHudRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Inject(method = "setOverlayMessage", at = @At("HEAD"))
    private void onSetOverlayMessage(class_2561 message, boolean tinted, CallbackInfo ci) {
        if (message != null) {
            ActionbarReader.updateText(message);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        ActionbarStorageClient clientInstance = ActionbarStorageClient.getInstance();

        if (clientInstance != null &&
                ActionbarStorageClient.getConfig() != null &&
                clientInstance.getManaManager() != null &&
                clientInstance.getCooldownTracker() != null) {

            StorageHudRenderer.render(
                    matrices,
                    ActionbarStorageClient.getConfig(),
                    clientInstance.getCooldownTracker(),
                    clientInstance.getManaManager(),
                    clientInstance.getGlobalTickCounter()
            );
        }
    }
}