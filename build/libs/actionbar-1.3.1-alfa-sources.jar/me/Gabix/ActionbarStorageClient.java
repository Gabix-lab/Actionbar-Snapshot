package me.Gabix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

public class ActionbarStorageClient implements ClientModInitializer {
    private static ActionbarStorageClient instance;
    private static StorageConfig savedConfig;

    public static class_304 configKeyBinding;
    public static class_304 resetCooldownKeyBinding;
    public static class_304 readActionbarKeyBinding;
    public static class_304 readBossBarsKeyBinding;
    public static class_304 toggleContinuousKeyBinding;

    private ManaManager manaManager;
    private CloneManager cloneManager;
    private CooldownTracker cooldownTracker;
    private int globalTickCounter = 0;
    private boolean wasAttackKeyPressedLastTick = false;

    @Override
    public void onInitializeClient() {
        instance = this;
        savedConfig = StorageConfig.load();
        this.manaManager = new ManaManager();
        this.cloneManager = new CloneManager();
        this.cooldownTracker = new CooldownTracker();

        configKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Actionbar Config Megnyitása",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "Actionbar Storage Mod"
        ));

        readActionbarKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Actionbar Nyers Beolvasása",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                "Actionbar Storage Mod"
        ));

        readBossBarsKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "BossBar Név Beolvasása",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                "Actionbar Storage Mod"
        ));

        resetCooldownKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Cooldown Nullázása",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_SEMICOLON,
                "Actionbar Storage Mod"
        ));

        toggleContinuousKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "Kész Felirat Mód Váltás",
                class_3675.class_307.field_1668,
                class_3675.method_15981("key.keyboard.apostrophe").method_1444(),
                "Actionbar Storage Mod"
        ));

        ActionbarReader.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            FullbrightManager.tick(client);

            globalTickCounter++;
            cloneManager.tick(globalTickCounter);

            ActionbarReader.handleTick(client);

            while (configKeyBinding.method_1436()) {
                if (savedConfig == null) {
                    savedConfig = StorageConfig.load();
                }
                client.method_1507(new StorageConfigScreen(savedConfig));
            }

            int activeSlot = client.field_1724.method_31548().field_7545;

            if (activeSlot >= 0 && activeSlot < 9 && getConfig().hudSlotsEnabled[activeSlot]) {

                while (resetCooldownKeyBinding.method_1436()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null) {
                        cooldownTracker.resetCooldowns(settings.cooldownKey());
                    }
                }

                boolean isAttackPressedNow = client.field_1690.field_1886.method_1434();
                boolean isLeftClicked = client.field_1690.field_1886.method_1436() || (isAttackPressedNow && !wasAttackKeyPressedLastTick);

                if (isLeftClicked) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.leftCD() > 0) {
                        if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), false)) {
                            cooldownTracker.registerLeftClick(settings.cooldownKey(), globalTickCounter, settings.leftCD());
                        }
                    }
                }

                wasAttackKeyPressedLastTick = isAttackPressedNow;

                if (client.field_1690.field_1904.method_1434() || client.field_1690.field_1904.method_1436()) {
                    class_1799 offhandStack = client.field_1724.method_6079();
                    SlotSettings offhandSettings = getSettingsForItem(offhandStack);
                    boolean offhandUsed = false;

                    if (offhandSettings != null && offhandSettings.cooldownKey() != null && offhandSettings.rightCD() > 0) {
                        if (cooldownTracker.isReady(offhandSettings.cooldownKey(), offhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                            cooldownTracker.registerRightClick(offhandSettings.cooldownKey(), globalTickCounter, offhandSettings.rightCD());
                            offhandUsed = true;
                        }
                    }

                    if (!offhandUsed) {
                        SlotSettings mainhandSettings = getSlotSettings(activeSlot);
                        if (mainhandSettings != null && mainhandSettings.cooldownKey() != null && mainhandSettings.rightCD() > 0) {
                            if (mainhandSettings.cooldownKey().startsWith("minecraft:paper:581")) {
                                if (cloneManager.getActiveClonesCount() < 2) {
                                    if (cooldownTracker.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                        cooldownTracker.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                        cloneManager.spawnClone(globalTickCounter);
                                    }
                                }
                            } else {
                                if (cooldownTracker.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                    cooldownTracker.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                }
                            }
                        }
                    }
                }
            } else {
                while (resetCooldownKeyBinding.method_1436()) {}
                wasAttackKeyPressedLastTick = false;
            }
        });
    }

    public static ActionbarStorageClient getInstance() {
        if (instance == null) {
            instance = new ActionbarStorageClient();
        }
        return instance;
    }

    public ManaManager getManaManager() { return this.manaManager; }
    public CloneManager getCloneManager() { return this.cloneManager; }
    public CooldownTracker getCooldownTracker() { return this.cooldownTracker; }
    public int getGlobalTickCounter() { return this.globalTickCounter; }

    public static StorageConfig getConfig() {
        if (savedConfig == null) {
            savedConfig = StorageConfig.load();
        }
        return savedConfig;
    }

    public static SlotSettings getSlotSettings(int slot) {
        net.minecraft.class_310 client = net.minecraft.class_310.method_1551();
        if (client.field_1724 == null || slot < 0 || slot > 8) return null;
        class_1799 stack = client.field_1724.method_31548().method_5438(slot);
        return getSettingsForItem(stack);
    }

    public static SlotSettings getSettingsForItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;

        StorageConfig config = getConfig();
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        int customModelData = 0;
        if (stack.method_7985() && stack.method_7969().method_10545("CustomModelData")) {
            customModelData = stack.method_7969().method_10550("CustomModelData");
        }

        String currentItemName = stack.method_7964().getString();
        String globalKey = itemId + ":" + customModelData;

        if (config.normalItems != null) {
            for (StorageConfig.ItemPreset preset : config.normalItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    return new SlotSettings(globalKey, currentItemName, preset.leftCD, preset.rightCD, preset.leftMana, preset.rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }

        if (config.leveledItems != null) {
            for (StorageConfig.LeveledItemPreset preset : config.leveledItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    int leftCdTicks = preset.leftCD;
                    int rightCdTicks = preset.rightCD;
                    int leftMana = preset.leftMana;
                    int rightMana = preset.rightMana;

                    if (preset.levels != null && currentItemName != null) {
                        for (StorageConfig.ItemLevel lvl : preset.levels) {
                            if (currentItemName.contains(lvl.levelNameIndicator)) {
                                leftCdTicks = lvl.leftCD;
                                rightCdTicks = lvl.rightCD;
                                leftMana = lvl.leftMana;
                                rightMana = lvl.rightMana;
                                break;
                            }
                        }
                    }
                    return new SlotSettings(globalKey, currentItemName, leftCdTicks, rightCdTicks, leftMana, rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        return null;
    }

    public record SlotSettings(String cooldownKey, String displayName, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {}
}