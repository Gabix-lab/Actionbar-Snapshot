package me.Gabix;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;

public class StorageHudRenderer {
    public static void render(MatrixStack matrices, StorageConfig config, CooldownTracker tracker, ManaManager manaManager, int globalTickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        TextRenderer textRenderer = client.textRenderer;
        ItemRenderer itemRenderer = client.getItemRenderer();
        PlayerInventory inventory = client.player.getInventory();
        int height = client.getWindow().getScaledHeight();

        int startX = 5, slotSize = 20;
        int totalHotbarHeight = 9 * slotSize;
        int startY = (height - totalHotbarHeight) / 2;

        CloneManager cloneManager = ActionbarStorageClient.getInstance().getCloneManager();

        for (int i = 0; i < 9; i++) {
            if (!config.hudSlotsEnabled[i]) continue;

            int slotY = startY + (i * slotSize);
            ItemStack stack = inventory.getStack(i);

            DrawableHelper.fill(matrices, startX, slotY, startX + slotSize, slotY + slotSize, 0x66000000);

            if (inventory.selectedSlot == i) {
                DrawableHelper.fill(matrices, startX, slotY, startX + slotSize, slotY + 1, 0xFFFFFFFF);
                DrawableHelper.fill(matrices, startX, slotY + slotSize - 1, startX + slotSize, slotY + slotSize, 0xFFFFFFFF);
                DrawableHelper.fill(matrices, startX, slotY, startX + 1, slotY + slotSize, 0xFFFFFFFF);
                DrawableHelper.fill(matrices, startX + slotSize - 1, slotY, startX + slotSize, slotY + slotSize, 0xFFFFFFFF);
            }

            if (!stack.isEmpty()) {
                itemRenderer.renderInGuiWithOverrides(matrices, stack, startX + 2, slotY + 2);
                itemRenderer.renderGuiItemOverlay(matrices, textRenderer, stack, startX + 2, slotY + 2);
            }

            ActionbarStorageClient.SlotSettings settings = ActionbarStorageClient.getSlotSettings(i);
            if (settings != null) {
                String key = settings.cooldownKey();
                if (key != null) {

                    if (key.startsWith("minecraft:paper:581") && cloneManager != null && cloneManager.getActiveClonesCount() >= 2) {
                        int nextExpiry = cloneManager.getNextExpiryTick();
                        int remTicks = Math.max(0, nextExpiry - globalTickCounter);
                        float secondsLeft = remTicks / 20.0f;

                        String foglaltStr = "§cFOGLALT §7(" + String.format("%.1f", secondsLeft) + ")";
                        textRenderer.drawWithShadow(matrices, foglaltStr, startX + slotSize + 4, slotY + 6, 0xFFFFFF);
                        continue;
                    }

                    String leftStr = "§7-";
                    String rightStr = "§7-";

                    int leftExpiry = tracker.getLeftExpiry(key);
                    int rightExpiry = tracker.getRightExpiry(key);

                    if (settings.leftCD() > 0) {
                        if (leftExpiry > globalTickCounter) {
                            int remTicks = leftExpiry - globalTickCounter;
                            leftStr = "§e" + String.format("%.1f", remTicks / 20.0f);
                        } else {
                            leftStr = "§akész";
                        }
                    }

                    if (settings.rightCD() > 0) {
                        if (rightExpiry > globalTickCounter) {
                            int remTicks = rightExpiry - globalTickCounter;
                            rightStr = "§d" + String.format("%.1f", remTicks / 20.0f);
                        } else {
                            rightStr = "§akész";
                        }
                    }

                    textRenderer.drawWithShadow(matrices, leftStr + " §f| " + rightStr, startX + slotSize + 4, slotY + 6, 0xFFFFFF);
                }
            } else {
                textRenderer.drawWithShadow(matrices, "§7- §f| §7-", startX + slotSize + 4, slotY + 6, 0xFFFFFF);
            }
        }

        textRenderer.drawWithShadow(matrices, "Mana: " + manaManager.getCurrentMana(), startX, startY + totalHotbarHeight + 4, 0x55FFFF);
    }
}