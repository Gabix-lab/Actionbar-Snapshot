package me.Gabix;

import java.util.ArrayList;
import java.util.List;

public class StorageConfig {
    public boolean[] hudSlotsEnabled = {true, true, true, true, true, true, true, true, true};
    public List<ItemPreset> normalItems = createDefaultNormalItems();
    public List<LeveledItemPreset> leveledItems = createDefaultLeveledItems();

    public String selectedBossNotification = "Ki";

    public int getTargetBossDamage() {
        return switch (selectedBossNotification) {
            case "JégSárkány" -> 6000;
            case "Trex" -> 20000;
            case "Endermágus" -> 3000;
            case "Warden" -> 10000;
            case "RadioPók" -> 15000;
            case "Kraken" -> 8000;
            default -> Integer.MAX_VALUE;
        };
    }

    private static List<ItemPreset> createDefaultNormalItems() {
        List<ItemPreset> list = new ArrayList<>();
        list.add(new ItemPreset("Tiger blade", "minecraft:paper", 524, 0, 800, 0, 15, 1, 0));
        list.add(new ItemPreset("Warden staff", "minecraft:paper", 550, 14, 0, 1, 0, 0, 0));
        list.add(new ItemPreset("Kraken gun", "minecraft:paper", 10658, 0, 26, 0, 0, 1, 0));
        list.add(new ItemPreset("Skeleton dragon staff", "minecraft:paper", 10637, 10, 600, 2, 12, 2, 0));
        list.add(new ItemPreset("Lunar horseshoe staff", "minecraft:paper", 10641, 10, 160, 0, 0, 2, 0));
        list.add(new ItemPreset("Easter slingshot", "minecraft:paper", 585, 600, 10, 8, 0, 2, 0));
        list.add(new ItemPreset("Lunar snake staff", "minecraft:paper", 581, 0, 40, 0, 5, 1, 2));
        return list;
    }

    private static List<LeveledItemPreset> createDefaultLeveledItems() {
        List<LeveledItemPreset> list = new ArrayList<>();
        LeveledItemPreset amethystSword = new LeveledItemPreset("Amethyst sword", "minecraft:paper", 562, 0, 800, 0, 15, 1, 0);
        amethystSword.levels.add(new ItemLevel("2. szint", 0, 700, 0, 14));
        amethystSword.levels.add(new ItemLevel("3. szint", 0, 700, 0, 14));
        amethystSword.levels.add(new ItemLevel("4. szint", 0, 600, 0, 12));
        amethystSword.levels.add(new ItemLevel("MAXIMUM SZINT", 0, 600, 0, 12));
        list.add(amethystSword);

        LeveledItemPreset amethystStaff = new LeveledItemPreset("Amethyst staff", "minecraft:paper", 569, 20, 1200, 2, 18, 1, 0);
        amethystStaff.levels.add(new ItemLevel("2. szint", 20, 1000, 2, 18));
        amethystStaff.levels.add(new ItemLevel("3. szint", 17, 1000, 1, 18));
        amethystStaff.levels.add(new ItemLevel("4. szint", 17, 1000, 1, 15));
        amethystStaff.levels.add(new ItemLevel("MAXIMUM SZINT", 14, 900, 1, 15));
        list.add(amethystStaff);
        return list;
    }

    public static class ItemLevel {
        public String levelNameIndicator;
        public int leftCD;
        public int rightCD;
        public int leftMana;
        public int rightMana;

        public ItemLevel() {}

        public ItemLevel(String levelNameIndicator, int leftCD, int rightCD, int leftMana, int rightMana) {
            this.levelNameIndicator = levelNameIndicator;
            this.leftCD = leftCD;
            this.rightCD = rightCD;
            this.leftMana = leftMana;
            this.rightMana = rightMana;
        }
    }

    public static class ItemPreset {
        public String name;
        public String itemId;
        public int customModelData;
        public int leftCD;
        public int rightCD;
        public int leftMana;
        public int rightMana;
        public int autoMode;
        public int maxCharges;

        public ItemPreset() {}

        public ItemPreset(String name, String itemId, int customModelData, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {
            this.name = name;
            this.itemId = itemId;
            this.customModelData = customModelData;
            this.leftCD = leftCD;
            this.rightCD = rightCD;
            this.leftMana = leftMana;
            this.rightMana = rightMana;
            this.autoMode = autoMode;
            this.maxCharges = maxCharges;
        }
    }

    public static class LeveledItemPreset extends ItemPreset {
        public List<ItemLevel> levels = new ArrayList<>();

        public LeveledItemPreset() { super(); }

        public LeveledItemPreset(String name, String itemId, int customModelData, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {
            super(name, itemId, customModelData, leftCD, rightCD, leftMana, rightMana, autoMode, maxCharges);
        }
    }

    public static StorageConfig load() {
        return new StorageConfig();
    }

    public void save() {}
}