package me.Gabix;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class StorageConfigScreen extends Screen {
    private final StorageConfig config;
    private ItemPresetListWidget listWidget;

    public StorageConfigScreen(StorageConfig config) {
        super(Text.literal("Actionbar Storage Beállítások"));
        this.config = config;
    }

    @Override
    protected void init() {
        this.listWidget = new ItemPresetListWidget(this.config);
        this.addSelectableChild(this.listWidget);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Bezárás"), button -> {
            this.config.save();
            this.close();
        }).dimensions(this.width / 2 - 100, this.height - 26, 200, 20).build());
    }

    // FŐ KATTINTÁS KEZELÉS A KÉPERNYŐN
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.client != null && this.client.player != null) {
            long windowHandle = this.client.getWindow().getHandle();

            // Ellenőrizzük, hogy a jobb oldali Shift le van-e nyomva
            if (InputUtil.isKeyPressed(windowHandle, GLFW.GLFW_KEY_RIGHT_SHIFT)) {

                // Megnézzük, hogy az egér a görgethető lista határain belül van-e
                if (mouseY >= this.listWidget.getTop() && mouseY <= this.listWidget.getBottom() && mouseX >= this.listWidget.getLeft() && mouseX <= this.listWidget.getRight()) {

                    // A nyilvános segédmetóduson keresztül kérjük le az elemet
                    ItemPresetListWidget.Entry hoveredEntry = this.listWidget.getHoveredEntry(mouseX, mouseY);
                    if (hoveredEntry != null) {

                        // 1. Sima tárgy sorra való kattintáskor
                        if (hoveredEntry instanceof ItemPresetListWidget.NormalItemEntry) {
                            StorageConfig.ItemPreset preset = ((ItemPresetListWidget.NormalItemEntry) hoveredEntry).preset;
                            String cmd = "give @s " + preset.itemId + "{CustomModelData:" + preset.customModelData + ",display:{Name:'{\"text\":\"" + preset.name.replace("§", "\\u00A7") + "\",\"italic\":false}'}}";
                            this.client.player.networkHandler.sendCommand(cmd);
                            return true;
                        }

                        // 2. Fejleszthető al-szintre való kattintáskor
                        if (hoveredEntry instanceof ItemPresetListWidget.LevelSubEntry) {
                            StorageConfig.ItemLevel level = ((ItemPresetListWidget.LevelSubEntry) hoveredEntry).level;
                            StorageConfig.LeveledItemPreset parentPreset = null;
                            if (this.config.leveledItems != null) {
                                for (StorageConfig.LeveledItemPreset p : this.config.leveledItems) {
                                    if (p.levels != null && p.levels.contains(level)) {
                                        parentPreset = p;
                                        break;
                                    }
                                }
                            }
                            if (parentPreset != null) {
                                String fullName = parentPreset.name + " " + level.levelNameIndicator;
                                String cmd = "give @s " + parentPreset.itemId + "{CustomModelData:" + parentPreset.customModelData + ",display:{Name:'{\"text\":\"" + fullName.replace("§", "\\u00A7") + "\",\"italic\":false}'}}";
                                this.client.player.networkHandler.sendCommand(cmd);
                                return true;
                            }
                        }

                        // 3. Fő lenyíló fejléc sorra való kattintáskor
                        if (hoveredEntry instanceof ItemPresetListWidget.LeveledItemHeaderEntry) {
                            StorageConfig.LeveledItemPreset preset = ((ItemPresetListWidget.LeveledItemHeaderEntry) hoveredEntry).preset;
                            String cmd = "give @s " + preset.itemId + "{CustomModelData:" + preset.customModelData + ",display:{Name:'{\"text\":\"" + preset.name.replace("§", "\\u00A7") + "\",\"italic\":false}'}}";
                            this.client.player.networkHandler.sendCommand(cmd);
                            return true;
                        }
                    }
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        this.listWidget.render(matrices, mouseX, mouseY, delta);
        drawCenteredTextWithShadow(matrices, this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
        super.render(matrices, mouseX, mouseY, delta);
    }

    private class ItemPresetListWidget extends ElementListWidget<ItemPresetListWidget.Entry> {
        public ItemPresetListWidget(StorageConfig config) {
            super(StorageConfigScreen.this.client, StorageConfigScreen.this.width, StorageConfigScreen.this.height, 24, StorageConfigScreen.this.height - 32, 24);

            this.addEntry(new BossNotificationEntry(config));
            this.addEntry(new HudSlotsToggleEntry(config));

            if (config.normalItems != null) {
                for (StorageConfig.ItemPreset preset : config.normalItems) {
                    this.addEntry(new NormalItemEntry(preset));
                }
            }

            if (config.leveledItems != null) {
                for (StorageConfig.LeveledItemPreset leveledPreset : config.leveledItems) {
                    LeveledItemHeaderEntry header = new LeveledItemHeaderEntry(leveledPreset, this);
                    this.addEntry(header);
                }
            }
        }

        // Ez a híd-metódus feloldja a protected hozzáférési hibát
        public Entry getHoveredEntry(double mouseX, double mouseY) {
            return this.getEntryAtPosition(mouseX, mouseY);
        }

        public int getLeft() { return this.left; }
        public int getRight() { return this.right; }
        public int getTop() { return this.top; }
        public int getBottom() { return this.bottom; }

        public void toggleLevels(LeveledItemHeaderEntry header, StorageConfig.LeveledItemPreset preset) {
            int headerIndex = this.children().indexOf(header);
            if (headerIndex == -1) return;

            if (header.isExpanded()) {
                int insertOffset = 1;
                for (StorageConfig.ItemLevel level : preset.levels) {
                    this.children().add(headerIndex + insertOffset, new LevelSubEntry(level));
                    insertOffset++;
                }
            } else {
                int numLevels = preset.levels.size();
                for (int i = 0; i < numLevels; i++) {
                    if (headerIndex + 1 < this.children().size() && this.children().get(headerIndex + 1) instanceof LevelSubEntry) {
                        this.children().remove(headerIndex + 1);
                    }
                }
            }
        }

        @Override
        public int getRowWidth() { return 360; }

        @Override
        protected int getScrollbarPositionX() { return this.width / 2 + 190; }

        abstract static class Entry extends ElementListWidget.Entry<Entry> {}

        private class BossNotificationEntry extends Entry {
            private final StorageConfig config;
            private final ButtonWidget cycleButton;
            private final List<net.minecraft.client.gui.Element> children = new ArrayList<>();
            private final List<ButtonWidget> selectables = new ArrayList<>();
            private final String[] choices = {"Ki", "JégSárkány", "Trex", "Endermágus", "Warden", "RadioPók", "Kraken"};

            public BossNotificationEntry(StorageConfig config) {
                this.config = config;

                this.cycleButton = ButtonWidget.builder(Text.literal(config.selectedBossNotification), button -> {
                    int currentIndex = 0;
                    for (int i = 0; i < choices.length; i++) {
                        if (choices[i].equals(config.selectedBossNotification)) {
                            currentIndex = i;
                            break;
                        }
                    }
                    int nextIndex = (currentIndex + 1) % choices.length;
                    config.selectedBossNotification = choices[nextIndex];
                    button.setMessage(Text.literal(config.selectedBossNotification));
                }).dimensions(0, 0, 100, 18).build();

                this.children.add(this.cycleButton);
                this.selectables.add(this.cycleButton);
            }

            @Override
            public void render(MatrixStack matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                fill(matrices, x, y, x + entryWidth, y + entryHeight - 2, 0x4400AAAA);
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, "§bBoss Sebzés Értesítő:", x + 6, y + 5, 0xFFFFFF);

                this.cycleButton.setX(x + entryWidth - 106);
                this.cycleButton.setY(y + 1);
                this.cycleButton.render(matrices, mouseX, mouseY, delta);
            }

            @Override
            public List<? extends net.minecraft.client.gui.Element> children() { return this.children; }
            @Override
            public List<? extends net.minecraft.client.gui.Selectable> selectableChildren() { return this.selectables; }
        }

        private class HudSlotsToggleEntry extends Entry {
            private final List<ButtonWidget> buttons = new ArrayList<>();
            private final List<net.minecraft.client.gui.Element> children = new ArrayList<>();

            public HudSlotsToggleEntry(StorageConfig config) {
                for (int i = 0; i < 9; i++) {
                    final int slotIndex = i;
                    boolean isEnabled = config.hudSlotsEnabled[slotIndex];
                    ButtonWidget btn = ButtonWidget.builder(Text.literal(String.valueOf(slotIndex + 1)), button -> {
                        config.hudSlotsEnabled[slotIndex] = !config.hudSlotsEnabled[slotIndex];
                        updateButtonColor(button, config.hudSlotsEnabled[slotIndex]);
                    }).dimensions(0, 0, 16, 18).build();

                    updateButtonColor(btn, isEnabled);
                    buttons.add(btn);
                    children.add(btn);
                }
            }

            private void updateButtonColor(ButtonWidget button, boolean enabled) {
                String num = button.getMessage().getString().replaceAll("§.", "");
                if (enabled) {
                    button.setMessage(Text.literal("§a" + num));
                } else {
                    button.setMessage(Text.literal("§c" + num));
                }
            }

            @Override
            public void render(MatrixStack matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                fill(matrices, x, y, x + entryWidth, y + entryHeight - 2, 0x4422AAAA);
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, "§eHUD Slotok:", x + 6, y + 5, 0xFFFFFF);

                int startX = x + entryWidth - 165;
                for (int i = 0; i < buttons.size(); i++) {
                    ButtonWidget btn = buttons.get(i);
                    btn.setX(startX + (i * 18));
                    btn.setY(y + 1);
                    btn.render(matrices, mouseX, mouseY, delta);
                }
            }

            @Override
            public List<? extends net.minecraft.client.gui.Element> children() { return this.children; }
            @Override
            public List<? extends net.minecraft.client.gui.Selectable> selectableChildren() { return this.buttons; }
        }

        public class NormalItemEntry extends Entry {
            public final StorageConfig.ItemPreset preset;
            private final List<net.minecraft.client.gui.Element> children = new ArrayList<>();

            public NormalItemEntry(StorageConfig.ItemPreset preset) { this.preset = preset; }

            @Override
            public void render(MatrixStack matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                int bgColor = hovered ? 0x44FFFFFF : 0x22FFFFFF;
                fill(matrices, x, y, x + entryWidth, y + entryHeight - 2, bgColor);

                String label = preset.name + " §7(CMD: " + preset.customModelData + ")";
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, label, x + 6, y + 6, 0xE0E0E0);
                String info = "§7B: §e" + (preset.leftCD / 20.0f) + "s §7| J: §d" + (preset.rightCD / 20.0f) + "s";
                int infoWidth = StorageConfigScreen.this.textRenderer.getWidth(info);
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, info, x + entryWidth - infoWidth - 6, y + 6, 0xFFFFFF);
            }

            @Override
            public List<? extends net.minecraft.client.gui.Element> children() { return this.children; }
            @Override
            public List<? extends net.minecraft.client.gui.Selectable> selectableChildren() { return java.util.Collections.emptyList(); }
        }

        public class LeveledItemHeaderEntry extends Entry {
            public final StorageConfig.LeveledItemPreset preset;
            private final ButtonWidget toggleButton;
            private final List<net.minecraft.client.gui.Element> children = new ArrayList<>();
            private final List<ButtonWidget> selectables = new ArrayList<>();
            private boolean expanded = false;

            public LeveledItemHeaderEntry(StorageConfig.LeveledItemPreset preset, ItemPresetListWidget parent) {
                this.preset = preset;
                this.toggleButton = ButtonWidget.builder(Text.literal("▶"), button -> {
                    this.expanded = !this.expanded;
                    button.setMessage(Text.literal(this.expanded ? "▼" : "▶"));
                    parent.toggleLevels(this, this.preset);
                }).dimensions(0, 0, 20, 18).build();
                this.children.add(this.toggleButton);
                this.selectables.add(this.toggleButton);
            }

            public boolean isExpanded() { return expanded; }

            @Override
            public void render(MatrixStack matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                fill(matrices, x, y, x + entryWidth, y + entryHeight - 2, 0x44AA00AA);
                this.toggleButton.setX(x + 4);
                this.toggleButton.setY(y + 1);
                this.toggleButton.render(matrices, mouseX, mouseY, delta);
                String label = "§6" + preset.name + " §7(CMD: " + preset.customModelData + ") §d[Fejleszthető]";
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, label, x + 28, y + 5, 0xFFFFFF);
            }

            @Override
            public List<? extends net.minecraft.client.gui.Element> children() { return this.children; }
            @Override
            public List<? extends net.minecraft.client.gui.Selectable> selectableChildren() { return this.selectables; }
        }

        public class LevelSubEntry extends Entry {
            public final StorageConfig.ItemLevel level;
            private final List<net.minecraft.client.gui.Element> children = new ArrayList<>();

            public LevelSubEntry(StorageConfig.ItemLevel level) { this.level = level; }

            @Override
            public void render(MatrixStack matrices, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                int bgColor = hovered ? 0x44000000 : 0x22000000;
                fill(matrices, x + 15, y, x + entryWidth, y + entryHeight - 2, bgColor);
                fill(matrices, x + 8, y, x + 9, y + entryHeight, 0x44FFFFFF);
                fill(matrices, x + 8, y + (entryHeight / 2), x + 14, y + (entryHeight / 2) + 1, 0x44FFFFFF);
                String lvlLabel = "§b• " + level.levelNameIndicator;
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, lvlLabel, x + 20, y + 6, 0xE0E0E0);
                String stats = "§7B: §e" + (level.leftCD / 20.0f) + "s (" + level.leftMana + "m) §7| J: §d" + (level.rightCD / 20.0f) + "s (" + level.rightMana + "m)";
                int statsWidth = StorageConfigScreen.this.textRenderer.getWidth(stats);
                StorageConfigScreen.this.textRenderer.drawWithShadow(matrices, stats, x + entryWidth - statsWidth - 6, y + 6, 0xCCCCCC);
            }

            @Override
            public List<? extends net.minecraft.client.gui.Element> children() { return this.children; }
            @Override
            public List<? extends net.minecraft.client.gui.Selectable> selectableChildren() { return java.util.Collections.emptyList(); }
        }
    }
}