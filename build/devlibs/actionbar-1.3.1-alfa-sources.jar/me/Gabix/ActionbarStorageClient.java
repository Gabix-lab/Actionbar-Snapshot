package me.Gabix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

public class ActionbarStorageClient implements ClientModInitializer {
    private static ActionbarStorageClient instance;
    private static StorageConfig savedConfig;

    public static KeyBinding configKeyBinding;
    public static KeyBinding resetCooldownKeyBinding;
    public static KeyBinding readActionbarKeyBinding;
    public static KeyBinding readBossBarsKeyBinding;
    public static KeyBinding toggleContinuousKeyBinding;

    private ManaManager manaManager;
    private CloneManager cloneManager;
    private CooldownTracker cooldownTracker;
    private int globalTickCounter = 0;
    private boolean wasAttackKeyPressedLastTick = false;

    @Override
    public void onInitializeClient() {
        instance = this;
        savedConfig = StorageConfig.load();
        this.manaManager = new ManaManager();
        this.cloneManager = new CloneManager();
        this.cooldownTracker = new CooldownTracker();

        configKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Actionbar Config Megnyitása",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "Actionbar Storage Mod"
        ));

        readActionbarKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Actionbar Nyers Beolvasása",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "Actionbar Storage Mod"
        ));

        readBossBarsKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "BossBar Név Beolvasása",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_J,
                "Actionbar Storage Mod"
        ));

        resetCooldownKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Cooldown Nullázása",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_SEMICOLON,
                "Actionbar Storage Mod"
        ));

        toggleContinuousKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Kész Felirat Mód Váltás",
                InputUtil.Type.KEYSYM,
                InputUtil.fromTranslationKey("key.keyboard.apostrophe").getCode(),
                "Actionbar Storage Mod"
        ));

        ActionbarReader.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            FullbrightManager.tick(client);

            globalTickCounter++;
            cloneManager.tick(globalTickCounter);

            ActionbarReader.handleTick(client);

            while (configKeyBinding.wasPressed()) {
                if (savedConfig == null) {
                    savedConfig = StorageConfig.load();
                }
                client.setScreen(new StorageConfigScreen(savedConfig));
            }

            int activeSlot = client.player.getInventory().selectedSlot;

            if (activeSlot >= 0 && activeSlot < 9 && getConfig().hudSlotsEnabled[activeSlot]) {

                while (resetCooldownKeyBinding.wasPressed()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null) {
                        cooldownTracker.resetCooldowns(settings.cooldownKey());
                    }
                }

                boolean isAttackPressedNow = client.options.attackKey.isPressed();
                boolean isLeftClicked = client.options.attackKey.wasPressed() || (isAttackPressedNow && !wasAttackKeyPressedLastTick);

                if (isLeftClicked) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.leftCD() > 0) {
                        if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), false)) {
                            cooldownTracker.registerLeftClick(settings.cooldownKey(), globalTickCounter, settings.leftCD());
                        }
                    }
                }

                wasAttackKeyPressedLastTick = isAttackPressedNow;

                if (client.options.useKey.isPressed() || client.options.useKey.wasPressed()) {
                    ItemStack offhandStack = client.player.getOffHandStack();
                    SlotSettings offhandSettings = getSettingsForItem(offhandStack);
                    boolean offhandUsed = false;

                    if (offhandSettings != null && offhandSettings.cooldownKey() != null && offhandSettings.rightCD() > 0) {
                        if (cooldownTracker.isReady(offhandSettings.cooldownKey(), offhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                            cooldownTracker.registerRightClick(offhandSettings.cooldownKey(), globalTickCounter, offhandSettings.rightCD());
                            offhandUsed = true;
                        }
                    }

                    if (!offhandUsed) {
                        SlotSettings mainhandSettings = getSlotSettings(activeSlot);
                        if (mainhandSettings != null && mainhandSettings.cooldownKey() != null && mainhandSettings.rightCD() > 0) {
                            if (mainhandSettings.cooldownKey().startsWith("minecraft:paper:581")) {
                                if (cloneManager.getActiveClonesCount() < 2) {
                                    if (cooldownTracker.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                        cooldownTracker.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                        cloneManager.spawnClone(globalTickCounter);
                                    }
                                }
                            } else {
                                if (cooldownTracker.isReady(mainhandSettings.cooldownKey(), mainhandSettings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                    cooldownTracker.registerRightClick(mainhandSettings.cooldownKey(), globalTickCounter, mainhandSettings.rightCD());
                                }
                            }
                        }
                    }
                }
            } else {
                while (resetCooldownKeyBinding.wasPressed()) {}
                wasAttackKeyPressedLastTick = false;
            }
        });
    }

    public static ActionbarStorageClient getInstance() {
        if (instance == null) {
            instance = new ActionbarStorageClient();
        }
        return instance;
    }

    public ManaManager getManaManager() { return this.manaManager; }
    public CloneManager getCloneManager() { return this.cloneManager; }
    public CooldownTracker getCooldownTracker() { return this.cooldownTracker; }
    public int getGlobalTickCounter() { return this.globalTickCounter; }

    public static StorageConfig getConfig() {
        if (savedConfig == null) {
            savedConfig = StorageConfig.load();
        }
        return savedConfig;
    }

    public static SlotSettings getSlotSettings(int slot) {
        net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
        if (client.player == null || slot < 0 || slot > 8) return null;
        ItemStack stack = client.player.getInventory().getStack(slot);
        return getSettingsForItem(stack);
    }

    public static SlotSettings getSettingsForItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;

        StorageConfig config = getConfig();
        String itemId = Registries.ITEM.getId(stack.getItem()).toString();
        int customModelData = 0;
        if (stack.hasNbt() && stack.getNbt().contains("CustomModelData")) {
            customModelData = stack.getNbt().getInt("CustomModelData");
        }

        String currentItemName = stack.getName().getString();
        String globalKey = itemId + ":" + customModelData;

        if (config.normalItems != null) {
            for (StorageConfig.ItemPreset preset : config.normalItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    return new SlotSettings(globalKey, currentItemName, preset.leftCD, preset.rightCD, preset.leftMana, preset.rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }

        if (config.leveledItems != null) {
            for (StorageConfig.LeveledItemPreset preset : config.leveledItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    int leftCdTicks = preset.leftCD;
                    int rightCdTicks = preset.rightCD;
                    int leftMana = preset.leftMana;
                    int rightMana = preset.rightMana;

                    if (preset.levels != null && currentItemName != null) {
                        for (StorageConfig.ItemLevel lvl : preset.levels) {
                            if (currentItemName.contains(lvl.levelNameIndicator)) {
                                leftCdTicks = lvl.leftCD;
                                rightCdTicks = lvl.rightCD;
                                leftMana = lvl.leftMana;
                                rightMana = lvl.rightMana;
                                break;
                            }
                        }
                    }
                    return new SlotSettings(globalKey, currentItemName, leftCdTicks, rightCdTicks, leftMana, rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        return null;
    }

    public record SlotSettings(String cooldownKey, String displayName, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {}
}