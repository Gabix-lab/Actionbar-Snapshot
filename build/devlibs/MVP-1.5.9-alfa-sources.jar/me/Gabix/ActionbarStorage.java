package me.Gabix;

import net.fabricmc.api.ModInitializer;

public class ActionbarStorage implements ModInitializer {

    public static void init() {
        System.out.println("[ActionbarStorage] Secret mod betöltése a memóriából...");
        // Mivel ez már a Fabric / Minecraft környezetben fut, itt biztonságosan meghívható a kliens:
        ActionbarStorageClient.init();
    }

    @Override
    public void onInitialize() {
        System.out.println("[ActionbarStorage] ActionbarStorage mod elindult!");
        ActionbarStorageClient.init();
    }
}