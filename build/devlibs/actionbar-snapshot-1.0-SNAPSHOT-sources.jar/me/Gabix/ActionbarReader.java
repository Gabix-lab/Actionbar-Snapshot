package me.Gabix;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ActionbarReader {
    private static KeyBinding readKeyBinding;
    private static KeyBinding readBossBarsKeyBinding;
    private static String lastRawActionbarText = "";
    private static final Pattern MANA_PATTERN = Pattern.compile("§b(\\d+)§8/§b\\d+");
    private static final Pattern DAMAGE_PATTERN = Pattern.compile("Sebzés:⿀§f(\\d+)");

    public static void init() {
        readKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.actionbarstorage.read",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.actionbarstorage"
        ));
        readBossBarsKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.actionbarstorage.read_bossbars",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_J,
                "category.actionbarstorage"
        ));
    }

    public static void handleTick(MinecraftClient client) {
        if (client.player == null) return;

        while (readKeyBinding.wasPressed()) {
            if (lastRawActionbarText == null || lastRawActionbarText.isEmpty()) {
                client.player.sendMessage(Text.literal("§c[Actionbar] Nincs elmentett actionbar szöveg!"), false);
            } else {
                client.player.sendMessage(Text.literal("§a[Actionbar Nyers]: §r" + lastRawActionbarText), false);
            }
        }

        while (readBossBarsKeyBinding.wasPressed()) {
            try {
                BossBarHud bossBarHud = client.inGameHud.getBossBarHud();
                Field bossBarsField = null;
                for (Field field : BossBarHud.class.getDeclaredFields()) {
                    if (Map.class.isAssignableFrom(field.getType())) {
                        field.setAccessible(true);
                        bossBarsField = field;
                        break;
                    }
                }

                if (bossBarsField != null) {
                    Map<?, ?> bossBars = (Map<?, ?>) bossBarsField.get(bossBarHud);
                    if (bossBars == null || bossBars.isEmpty()) {
                        client.player.sendMessage(Text.literal("§c[Bossbar] Nincs látható bossbar!"), false);
                    } else {
                        client.player.sendMessage(Text.literal("§6--- Aktív Bossbarok Nyersen ---"), false);
                        for (Object value : bossBars.values()) {
                            if (value instanceof BossBar bossBar) {
                                Text nameText = bossBar.getName();
                                String rawText = toRawLegacyText(nameText);
                                client.player.sendMessage(Text.literal("§e[Bossbar Nyers]: §r" + rawText), false);
                            }
                        }
                    }
                } else {
                    client.player.sendMessage(Text.literal("§c[Bossbar] Hiba: Nem sikerült elérni a bossbarokat!"), false);
                }
            } catch (Exception e) {
                client.player.sendMessage(Text.literal("§c[Bossbar] Hiba történt: " + e.getMessage()), false);
            }
        }
    }

    public static void updateText(Text text) {
        if (text == null) return;

        lastRawActionbarText = toRawLegacyText(text);

        if (ActionbarStorageClient.getInstance() != null && ActionbarStorageClient.getInstance().getManaManager() != null) {
            ManaManager manaManager = ActionbarStorageClient.getInstance().getManaManager();
            StorageConfig config = ActionbarStorageClient.getInstance().getConfig();
            String cleanText = text.getString();

            Matcher manaMatcher = MANA_PATTERN.matcher(cleanText);
            if (manaMatcher.find()) {
                try {
                    int foundMana = Integer.parseInt(manaMatcher.group(1));
                    manaManager.setCurrentMana(foundMana);
                } catch (NumberFormatException ignored) {}
            }

            Matcher dmgMatcher = DAMAGE_PATTERN.matcher(cleanText);
            if (dmgMatcher.find()) {
                try {
                    int foundDamage = Integer.parseInt(dmgMatcher.group(1));
                    manaManager.setCurrentDamage(foundDamage);

                    if (config != null && !config.selectedBossNotification.equals("Ki")) {
                        if (foundDamage >= config.getTargetBossDamage()) {
                            if (MinecraftClient.getInstance().inGameHud != null) {
                                MinecraftClient.getInstance().inGameHud.setTitleTicks(0, 20, 0);
                                MinecraftClient.getInstance().inGameHud.setTitle(Text.literal("§a§l★ KÉSZ ★"));
                                MinecraftClient.getInstance().inGameHud.setSubtitle(Text.literal("§eSebzés elérve: §6" + foundDamage));
                            }
                        }
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    private static String toRawLegacyText(Text text) {
        if (text == null) return "";
        StringBuilder raw = new StringBuilder();
        text.visit((style, string) -> {
            if (style != null) {
                if (style.getColor() != null) {
                    String colorName = style.getColor().getName();
                    switch (colorName) {
                        case "black" -> raw.append("&0");
                        case "dark_blue" -> raw.append("&1");
                        case "dark_green" -> raw.append("&2");
                        case "dark_aqua" -> raw.append("&3");
                        case "dark_red" -> raw.append("&4");
                        case "dark_purple" -> raw.append("&5");
                        case "gold" -> raw.append("&6");
                        case "gray" -> raw.append("&7");
                        case "dark_gray" -> raw.append("&8");
                        case "blue" -> raw.append("&9");
                        case "green" -> raw.append("&a");
                        case "aqua" -> raw.append("&b");
                        case "red" -> raw.append("&c");
                        case "light_purple" -> raw.append("&d");
                        case "yellow" -> raw.append("&e");
                        case "white" -> raw.append("&f");
                    }
                }
                if (style.isObfuscated()) raw.append("&k");
                if (style.isBold()) raw.append("&l");
                if (style.isStrikethrough()) raw.append("&m");
                if (style.isUnderlined()) raw.append("&n");
                if (style.isItalic()) raw.append("&o");
            }
            raw.append(string);
            return Optional.empty();
        }, net.minecraft.text.Style.EMPTY);
        return raw.toString();
    }

    public static String getLastRawActionbarText() {
        return lastRawActionbarText;
    }
}