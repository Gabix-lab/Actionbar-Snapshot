package me.Gabix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

public class ActionbarStorageClient implements ClientModInitializer {
    private static ActionbarStorageClient instance;
    private static StorageConfig savedConfig;
    private static KeyBinding configKeyBinding;
    private static KeyBinding resetCooldownKeyBinding;

    private ManaManager manaManager;
    private CloneManager cloneManager;
    private CooldownTracker cooldownTracker;
    private int globalTickCounter = 0;
    private boolean isHandSwingingLastTick = false;

    @Override
    public void onInitializeClient() {
        instance = this;
        savedConfig = StorageConfig.load();
        this.manaManager = new ManaManager();
        this.cloneManager = new CloneManager();
        this.cooldownTracker = new CooldownTracker();

        ActionbarReader.init();

        configKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.actionbarstorage.config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.actionbarstorage"
        ));

        resetCooldownKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.actionbarstorage.reset",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_SEMICOLON,
                "category.actionbarstorage"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            globalTickCounter++;
            cloneManager.tick(globalTickCounter);
            ActionbarReader.handleTick(client);

            while (configKeyBinding.wasPressed()) {
                if (savedConfig == null) {
                    savedConfig = StorageConfig.load();
                }
                client.setScreen(new StorageConfigScreen(savedConfig));
            }

            int activeSlot = client.player.getInventory().selectedSlot;

            if (activeSlot >= 0 && activeSlot < 9 && getConfig().hudSlotsEnabled[activeSlot]) {

                while (resetCooldownKeyBinding.wasPressed()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null) {
                        cooldownTracker.resetCooldowns(settings.cooldownKey());
                    }
                }

                boolean isSwingingNow = client.player.handSwinging && client.player.handSwingTicks == 0;
                boolean isLeftClicked = client.options.attackKey.wasPressed() || (isSwingingNow && !isHandSwingingLastTick);

                if (isLeftClicked) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.leftCD() > 0) {
                        if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), false)) {
                            cooldownTracker.registerLeftClick(settings.cooldownKey(), globalTickCounter, settings.leftCD());
                        }
                    }
                }

                if (client.options.useKey.isPressed() || client.options.useKey.wasPressed()) {
                    SlotSettings settings = getSlotSettings(activeSlot);
                    if (settings != null && settings.cooldownKey() != null && settings.rightCD() > 0) {
                        if (settings.cooldownKey().startsWith("minecraft:paper:581")) {
                            if (cloneManager.getActiveClonesCount() < 2) {
                                if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                    cooldownTracker.registerRightClick(settings.cooldownKey(), globalTickCounter, settings.rightCD());
                                    cloneManager.spawnClone(globalTickCounter);
                                }
                            }
                        } else {
                            if (cooldownTracker.isReady(settings.cooldownKey(), settings, globalTickCounter, manaManager.getCurrentMana(), true)) {
                                cooldownTracker.registerRightClick(settings.cooldownKey(), globalTickCounter, settings.rightCD());
                            }
                        }
                    }
                }
            } else {
                while (resetCooldownKeyBinding.wasPressed()) {}
            }

            isHandSwingingLastTick = client.player.handSwinging;
        });
    }

    public static ActionbarStorageClient getInstance() {
        if (instance == null) {
            instance = new ActionbarStorageClient();
        }
        return instance;
    }

    public ManaManager getManaManager() { return this.manaManager; }
    public CloneManager getCloneManager() { return this.cloneManager; }
    public CooldownTracker getCooldownTracker() { return this.cooldownTracker; }
    public int getGlobalTickCounter() { return this.globalTickCounter; }

    public static StorageConfig getConfig() {
        if (savedConfig == null) {
            savedConfig = StorageConfig.load();
        }
        return savedConfig;
    }

    public static SlotSettings getSlotSettings(int slot) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || slot < 0 || slot > 8) return null;
        ItemStack stack = client.player.getInventory().getStack(slot);
        return getSettingsForItem(stack);
    }

    public static SlotSettings getSettingsForItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;

        StorageConfig config = getConfig();
        String itemId = Registries.ITEM.getId(stack.getItem()).toString();
        int customModelData = 0;
        if (stack.hasNbt() && stack.getNbt().contains("CustomModelData")) {
            customModelData = stack.getNbt().getInt("CustomModelData");
        }

        String currentItemName = stack.getName().getString();
        String globalKey = itemId + ":" + customModelData;

        if (config.normalItems != null) {
            for (StorageConfig.ItemPreset preset : config.normalItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    return new SlotSettings(globalKey, currentItemName, preset.leftCD, preset.rightCD, preset.leftMana, preset.rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }

        if (config.leveledItems != null) {
            for (StorageConfig.LeveledItemPreset preset : config.leveledItems) {
                if (preset.itemId.equals(itemId) && preset.customModelData == customModelData) {
                    int leftCdTicks = preset.leftCD;
                    int rightCdTicks = preset.rightCD;
                    int leftMana = preset.leftMana;
                    int rightMana = preset.rightMana;

                    if (preset.levels != null && currentItemName != null) {
                        for (StorageConfig.ItemLevel lvl : preset.levels) {
                            if (currentItemName.contains(lvl.levelNameIndicator)) {
                                leftCdTicks = lvl.leftCD;
                                rightCdTicks = lvl.rightCD;
                                leftMana = lvl.leftMana;
                                rightMana = lvl.rightMana;
                                break;
                            }
                        }
                    }
                    return new SlotSettings(globalKey, currentItemName, leftCdTicks, rightCdTicks, leftMana, rightMana, preset.autoMode, preset.maxCharges);
                }
            }
        }
        return null;
    }

    public record SlotSettings(String cooldownKey, String displayName, int leftCD, int rightCD, int leftMana, int rightMana, int autoMode, int maxCharges) {}
}